package reponse.admin;

import org.junit.Test;

import static org.junit.Assert.*;

public class BanHangRepositoryTest {
    BanHangRepository bhr = new BanHangRepository();

    @Test
    public void testGetKH(){
        assertEquals("abc", bhr.getIdByName("abc").getHoTen());
    }

}