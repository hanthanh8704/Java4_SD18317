package controller.user;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.ChiTietSanPham;
import model.SanPham;
import reponse.user.UserRepon;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "SearchServlet", value = {
        "/search"
})
public class SearchServlet extends HttpServlet {
    private final UserRepon repon = new UserRepon();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String searchTxT = request.getParameter("txt");
        List<ChiTietSanPham> listCTSPSearch = repon.searchChiTietSanPhamByName(searchTxT);
        request.setAttribute("listCTSP",listCTSPSearch);
        // Hàm này lấy ra các danh mục sản phẩm và sản phẩm mới mnhaast
        List<SanPham> listSP = repon.getAllCategory();
        ChiTietSanPham ctsp = repon.getSanPhamNew();
        request.setAttribute("listSP",listSP);
        request.setAttribute("p",ctsp);
        request.setAttribute("txtSearch",searchTxT);
        request.getRequestDispatcher("/view/user/home-user.jsp").forward(request,response);
    }
}
