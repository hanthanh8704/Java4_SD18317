package controller.user;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.ChiTietSanPham;
import model.SanPham;
import reponse.user.UserRepon;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "UserSanPhamServlet", value = {
        "/san-pham"
})
public class UserSanPhamServlet extends HttpServlet {
    private final UserRepon repon = new UserRepon();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Lấy id sản phẩm
        Integer idSanPham = Integer.valueOf(request.getParameter("id"));
        List<ChiTietSanPham> listCTSP2 = repon.getChiTietSanPhamById(idSanPham);
        request.setAttribute("listCTSP", listCTSP2);
        // Hàm này lấy ra các danh mục sản phẩm và sản phẩm mới mnhaast
        List<SanPham> listSP = repon.getAllCategory();
        ChiTietSanPham ctsp = repon.getSanPhamNew();
        request.setAttribute("listSP",listSP);
        request.setAttribute("p",ctsp);
        request.setAttribute("tag",idSanPham);
        request.getRequestDispatcher("/view/user/home-user.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
