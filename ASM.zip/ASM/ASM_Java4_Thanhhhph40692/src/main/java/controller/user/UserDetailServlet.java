package controller.user;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.ChiTietSanPham;
import model.SanPham;
import reponse.user.UserRepon;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "UserDetailServlet", value = {
        "/detail"
})
public class UserDetailServlet extends HttpServlet {
    private final UserRepon repon = new UserRepon();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Integer id = Integer.valueOf(request.getParameter("id"));
        ChiTietSanPham ctspDetail = repon.getDetailChiTietSanPhamById(id);
        request.setAttribute("detail",ctspDetail);
        // Hàm này lấy ra các danh mục sản phẩm và sản phẩm mới mnhaast
        List<SanPham> listSP = repon.getAllCategory();
        ChiTietSanPham ctsp = repon.getSanPhamNew();
        request.setAttribute("listSP",listSP);
        request.setAttribute("p",ctsp);
        request.getRequestDispatcher("/view/user/detail.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
