package controller.user;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.ChiTietSanPham;
import model.MauSac;
import model.SanPham;
import model.Size;
import reponse.admin.MauSacRepon;
import reponse.admin.SanPhamRepon;
import reponse.admin.SizeRepon;
import reponse.user.UserRepon;
import util.TimeUtil;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "ManegerServlet", value = {
        "/maneger"
})
public class ManegerServlet extends HttpServlet {
    List<ChiTietSanPham> listCTSP = new ArrayList<>();
    UserRepon repon = new UserRepon();
    private SanPhamRepon reponSanPham = new SanPhamRepon();
    private MauSacRepon reponMauSac = new MauSacRepon();
    private SizeRepon reponSize = new SizeRepon();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<ChiTietSanPham> list = repon.getAllProduct();
        request.setAttribute("listCTSP",list);
        // Lấy ra sản phẩm
        List<SanPham> listSanPham = reponSanPham.getAll();
        request.setAttribute("listSanPham", listSanPham);
        // Lấy ra size
        List<Size> listSize = reponSize.getAll();
        request.setAttribute("listSize", listSize);
        // Lấy ra màu sắc
        List<MauSac> listMauSac = reponMauSac.getAll();
        request.setAttribute("listMauSac", listMauSac);

        request.getRequestDispatcher("/view/user/ManagerProduct.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }

}
