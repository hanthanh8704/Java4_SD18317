package controller.user;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.ChiTietSanPham;
import model.SanPham;
import reponse.user.UserRepon;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "UserServlet", value = "/home-user")
public class HomeUserServlet extends HttpServlet {
    private final UserRepon repon = new UserRepon();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        hienThi(request, response);
    }

    private void hienThi(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Hàm này lấy ra toàn bộ chi tiết sản phẩm
        List<ChiTietSanPham> listCTSP = repon.getAllProduct();
        // Hàm này lấy ra các sản phẩm
        List<SanPham> listSP = repon.getAllCategory();
        // Hàm này lấy ra sản phẩm mới nhất
        ChiTietSanPham ctsp = repon.getSanPhamNew();
        request.setAttribute("listCTSP", listCTSP);
        request.setAttribute("listSP",listSP);
        request.setAttribute("p",ctsp);
        request.getRequestDispatcher("/view/user/home-user.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

}
