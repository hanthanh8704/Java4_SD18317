package controller.user;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.ChiTietSanPham;
import model.MauSac;
import model.SanPham;
import model.Size;
import reponse.admin.ChiTietSanPhamRepon;
import reponse.admin.MauSacRepon;
import reponse.admin.SanPhamRepon;
import reponse.admin.SizeRepon;
import reponse.user.UserRepon;
import util.TimeUtil;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

@WebServlet(name = "UpdateServlet", value = {
        "/edit"
})
public class UpdateServlet extends HttpServlet {
    private SanPhamRepon reponSanPham = new SanPhamRepon();
    private MauSacRepon reponMauSac = new MauSacRepon();
    private SizeRepon reponSize = new SizeRepon();
    private ChiTietSanPhamRepon reponCTSP = new ChiTietSanPhamRepon();
    UserRepon repon = new UserRepon();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Integer id = Integer.valueOf(request.getParameter("id"));
        ChiTietSanPham ctsp = reponCTSP.getChiTietSanPhamByMa(id);

        // Lấy ra sản phẩm
        List<SanPham> listSanPham = reponSanPham.getAll();
        request.setAttribute("listSanPham", listSanPham);
        // Lấy ra size
        List<Size> listSize = reponSize.getAll();
        request.setAttribute("listSize", listSize);
        // Lấy ra màu sắc
        List<MauSac> listMauSac = reponMauSac.getAll();
        request.setAttribute("listMauSac", listMauSac);

        List<SanPham> listSP = repon.getAllCategory();
        request.setAttribute("listSP",listSP);


        request.setAttribute("updateCTSP",ctsp);
        request.getRequestDispatcher("/view/user/edit.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Integer id = Integer.valueOf(request.getParameter("id"));
            Integer idSanPham = Integer.valueOf(request.getParameter("sanPham"));
            Integer idMauSac = Integer.valueOf(request.getParameter("mauSac"));
            Integer idKichCo = Integer.valueOf(request.getParameter("kichCo"));
            // Chuyển đổi String sang BigDecimal
            BigDecimal giaBan = null;
            try {
                giaBan = BigDecimal.valueOf(Double.parseDouble(request.getParameter("giaBan")));
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
            Integer soLuong = Integer.valueOf(request.getParameter("soLuongTon"));
            String trangThai = request.getParameter("trangThai");

            // Kiểm tra xem ID có được sửa đổi không
            Integer newId = Integer.valueOf(request.getParameter("id"));
            if (!id.equals(newId)) {
                response.sendRedirect("/chi-tiet-san-pham/update");
            }

            // Tạo đối tượng Sản Phẩm
            SanPham sp = new SanPham();
            sp.setId(idSanPham);
            // Tạo đối tượng màu sắc
            MauSac ms = new MauSac();
            ms.setId(idMauSac);
            // Tạo đối tượng kích cỡ
            Size s = new Size();
            s.setId(idKichCo);
            // Tạo đối tượng SanPhamCT
            ChiTietSanPham ctsp = ChiTietSanPham.builder()
                    .sanPham(sp)
                    .mauSac(ms)
                    .size(s)
                    .giaBan(giaBan)
                    .soLuongTon(soLuong)
                    .trangThai(trangThai)
                    .ngayTao(TimeUtil.timeNow())
                    .build();
            reponCTSP.update(ctsp,id);
            response.sendRedirect("/chi-tiet-san-pham/hien-thi");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
