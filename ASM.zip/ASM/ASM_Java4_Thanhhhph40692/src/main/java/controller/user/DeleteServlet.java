package controller.user;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import reponse.admin.ChiTietSanPhamRepon;
import reponse.user.UserRepon;

import java.io.IOException;

@WebServlet(name = "DeleteServlet", value = {
        "/delete"
})
public class DeleteServlet extends HttpServlet {
    UserRepon repon = new UserRepon();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Integer pid = Integer.valueOf(request.getParameter("pid"));
        repon.delete(pid);
        response.sendRedirect("/maneger");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
