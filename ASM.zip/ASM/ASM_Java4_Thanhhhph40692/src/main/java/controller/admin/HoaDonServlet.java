package controller.admin;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.HoaDon;
import model.HoaDonChiTiet;
import model.HoaDonPage;
import reponse.admin.HoaDonRepon;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "HoaDonServlet", value = {
        "/hoa-don/hien-thi",
        "/hoa-don/detailHDCT",
        "/hoa-don/search",
        "/hoa-don/phan-trang",
})
public class HoaDonServlet extends HttpServlet {
    HoaDonRepon repon = new HoaDonRepon();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.contains("/hoa-don/hien-thi")) {
            this.hienThi(request, response);
        } else if (uri.contains("/hoa-don/detailHDCT")) {
            this.detailHDCT(request, response);
        } else if (uri.equals("/hoa-don/phan-trang")) {
            System.out.println("doGet of /hoa-don/phan-trang");
            phanTrang(request, response);
        } else {
            this.hienThi(request, response);
        }
    }

    private void phanTrang(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("Bat dau phan trang");
        List<HoaDon> listHD = repon.getAllHD();
        System.out.println("So luong hoa don : " + listHD.size());
        request.setAttribute("listHD", listHD);
        int idHoaDon = Integer.parseInt(request.getParameter("idHoaDon"));
        System.out.println("Id hoa don : " + idHoaDon);
        int pageNo = Integer.parseInt(request.getParameter("pageno"));
        System.out.println("So trang  : " + pageNo);
        int pageSize = 3;
        HoaDonPage page = repon.paging(idHoaDon, pageNo, pageSize);
        System.out.println("1" + page.getHoaDonList());
        System.out.println("2" + page.getTotalPage());
        System.out.println("3" + page.getCurrentPage());
        request.setAttribute("idHoaDon", idHoaDon);
        request.setAttribute("listHD", page.getHoaDonList());
        request.setAttribute("totalpage", page.getTotalPage());
        request.setAttribute("currentpage", page.getCurrentPage());
        request.getRequestDispatcher("/view/admin/hoaDon/hoa-don.jsp").forward(request, response);
    }


    private void detailHDCT(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("Alo");
        System.out.println(request.getParameter("id"));
        if (request.getParameter("id") != null) {
            request.setAttribute("listHDCT", repon.listHDCTByIDHoaDon(Integer.parseInt(request.getParameter("id"))));
            hienThi(request, response);
        }
    }

    private void hienThi(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("dong 51");
        List<HoaDon> listHD = repon.getAllHD();
        List<HoaDon> listHDDTT = repon.getListDTT();
        List<HoaDon> listHDCTT = repon.getListCTTT();
        System.out.println("Dong 53");
        request.setAttribute("listHD", listHD);
        request.setAttribute("listHDDTT", listHDDTT);
        request.setAttribute("listHDCTT", listHDCTT);
        System.out.println("Dong 55");
        request.getRequestDispatcher("/view/admin/hoaDon/hoa-don.jsp").forward(request, response);
        System.out.println("Dong 57");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.equals("/hoa-don/search")) {
            this.searchCBB(request, response);
        }
    }


    private void searchCBB(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("txt");
        String sdt = request.getParameter("txt");
        String diaChi = request.getParameter("txt");
        List<HoaDon> list = repon.searchHDbyNamebyDiaChibySDT(name, sdt, diaChi);
        request.setAttribute("listHD", list);
        request.getRequestDispatcher("/view/admin/hoaDon/hoa-don.jsp").forward(request, response);
    }
}
