package controller.admin;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.HoaDonChiTiet;
import reponse.admin.HoaDonChiTietRepon;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "HoaDonChiTietServlet", value = {
        "/hoa-don-chi-tiet/hien-thi",
        "/hoa-don-chi-tiet/detail"
})
public class HoaDonChiTietServlet extends HttpServlet {
    HoaDonChiTietRepon repon = new HoaDonChiTietRepon();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if(uri.contains("/hoa-don-chi-tiet/hien-thi")){
            this.hienThi(request,response);
        } else if (uri.contains("/hoa-don-chi-tiet/detail")) {
            this.detail(request,response);
        }
    }

    private void detail(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Integer id = Integer.valueOf(request.getParameter("id"));
        HoaDonChiTiet hdct = repon.getHoaDonChiTietById(id);
        request.setAttribute("detailHoaDon",hdct);
        request.getRequestDispatcher("/view/admin/chiTietHoaDon/detail-hoa-don-chi-tiet.jsp").forward(request,response);
    }

    private void hienThi(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<HoaDonChiTiet> listHDCT = repon.getAll();
        request.setAttribute("listHDCT",listHDCT);
        request.getRequestDispatcher("/view/admin/hoaDonChiTiet/hoa-don-chi-tiet.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
