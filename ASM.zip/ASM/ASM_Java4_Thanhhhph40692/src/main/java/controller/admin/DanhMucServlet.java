package controller.admin;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.DanhMuc;
import model.Size;
import reponse.admin.DanhMucRepon;
import util.GenMaTuDong;
import util.TimeUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@WebServlet(name = "DongSPServlet", value = {
        "/danh-muc/hien-thi",
        "/danh-muc/add",
        "/danh-muc/update",
        "/danh-muc/detail",
        "/danh-muc/view-add",
        "/danh-muc/delete",
        "/danh-muc/search",
})
public class DanhMucServlet extends HttpServlet {

    private DanhMucRepon repon = new DanhMucRepon();
    private List<DanhMuc> listDM = new ArrayList<>();
    private TimeUtil timeUtil = new TimeUtil();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if(uri.contains("hien-thi")){
            this.hienThi(request,response); // Hiển thị danh sách các size
        }else if(uri.contains("view-add")){
            this.viewAdd(request,response); // Hiển thị giao diện thêm mới size
        }else if(uri.contains("update")){
            this.viewUpdate(request,response); // Hiển thị giao diện cập nhật size
        } else if (uri.contains("delete")) {
            this.delete(request,response); // Xóa size
        } else if (uri.contains("detail")) {
            this.detail(request,response); // Xem chi tiết size
        }else {
            this.hienThi(request,response); // Mặc định hiển thị danh sách size
        }
    }

    private void detail(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String ma = request.getParameter("ma");
        DanhMuc danhMuc = repon.getDanhMucByMa(ma);
        request.setAttribute("detailDanhMuc",danhMuc);
        request.getRequestDispatcher("/view/admin/danhMuc/detail-danh-muc.jsp").forward(request,response);
    }

    private void delete(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String ma = request.getParameter("ma");
        DanhMuc danhMuc = repon.getDanhMucByMa(ma);
        repon.delete(danhMuc);
        response.sendRedirect("/danh-muc/hien-thi");
    }

    private void viewUpdate(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String ma = request.getParameter("ma");
        DanhMuc danhMuc = repon.getDanhMucByMa(ma);
        request.setAttribute("updateDanhMuc",danhMuc);
        request.getRequestDispatcher("/view/admin/danhMuc/update-danh-muc.jsp").forward(request,response);
    }

    private void viewAdd(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("hihi");
        request.setAttribute("addDanhMuc","/view/admin/danhMuc/add-danh-muc.jsp");
        request.getRequestDispatcher("/view/admin/danhMuc/add-danh-muc.jsp").forward(request,response);
    }

    private void hienThi(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<DanhMuc> list = repon.getAll();
        request.setAttribute("listDanhMuc",list);
        request.getRequestDispatcher("/view/admin/danhMuc/list-danh-muc.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if(uri.contains("add")){
            this.add(request,response); // Thêm mới size
        } else if (uri.contains("update")) {
            this.update(request,response); // Cập nhật size
        } else if (uri.contains("/danh-muc/search")) {
            this.search(request,response);
        }
    }

    private void search(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("txt");
        String ma = request.getParameter("txt");
        List<DanhMuc> list = repon.searchDanhMucbyNamebyMa(name,ma);
        request.setAttribute("listDanhMuc",list);
        request.setAttribute("txtSearch",name);
        request.setAttribute("txtSearch",ma);
        request.getRequestDispatcher("/view/admin/danhMuc/list-danh-muc.jsp").forward(request,response);
    }

    private void update(HttpServletRequest request, HttpServletResponse response) {
        try {
            String ma = request.getParameter("ma");
            System.out.println("Mã :" + ma);
            String ten = request.getParameter("ten");
            System.out.println("Tên :" + ten);
            String trangthai = request.getParameter("trangThai");
            System.out.println("Trạng thái : " + trangthai);
            if (ma.trim().isEmpty() || ten.trim().isEmpty()) {
                request.getSession().setAttribute("mess_error", "Vui lòng không bỏ trống");
                response.sendRedirect("/danh-muc/update");
                return;
            }

            DanhMuc dm = DanhMuc.builder()
                    .maDanhMuc(ma)
                    .tenDanhMuc(ten)
                    .trangThai(trangthai)
                    .ngaySua(TimeUtil.timeNow())
                    .build();
            // Gọi service để cập nhật màu sắc
            if (repon.update(dm, ma)) {
                request.getSession().setAttribute("mess", "Cap nhat thanh cong");
                response.sendRedirect("/danh-muc/hien-thi");
            } else {
                request.getSession().setAttribute("mess-error", "Cap nhat that bai");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void add(HttpServletRequest request, HttpServletResponse response) {
        try {
            // Tạo mã tự sinh
            GenMaTuDong taoMa = new GenMaTuDong() {
                @Override
                public String maTuDong() {
                    //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                    int gen = new Random().nextInt(1000000);
                    return "MS" + gen;
                }
            };
            String ma = taoMa.maTuDong();
            System.out.println("Mã :" + ma);
            String ten = request.getParameter("ten");
            System.out.println("Tên :" + ten);
            String trangthai = request.getParameter("trangThai");
            System.out.println("Trạng thái : " + trangthai);
            if (ma.trim().isEmpty() || ten.trim().isEmpty()) {
                request.getSession().setAttribute("error", "Vui lòng không bỏ trống");
                response.sendRedirect("/danh-muc/view-add");
                return;
            }

            DanhMuc dm = DanhMuc.builder()
                    .maDanhMuc(ma)
                    .tenDanhMuc(ten)
                    .trangThai(trangthai)
                    .ngayTao(TimeUtil.timeNow())
                    .build();
            listDM.add(dm);
            // Gọi service để thêm mới giảng viên vào cơ sở dữ liệu
            if (repon.add(dm)) {
                request.getSession().setAttribute("mess", "Them moi thanh cong");
                // Redirect về trang chủ
                response.sendRedirect("/danh-muc/hien-thi");
            } else {
                request.getSession().setAttribute("mess-error", "Them moi that bai");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
