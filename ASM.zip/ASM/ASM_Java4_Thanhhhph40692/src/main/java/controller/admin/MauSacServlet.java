package controller.admin;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.MauSac;
import reponse.admin.MauSacRepon;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import util.GenMaTuDong;
import util.TimeUtil;

@WebServlet(name = "MauSacServlet", value = {
        "/mau-sac/hien-thi",
        "/mau-sac/view-add",
        "/mau-sac/add",
        "/mau-sac/delete",
        "/mau-sac/detail",
        "/mau-sac/search",
        "/mau-sac/update"
})
public class MauSacServlet extends HttpServlet {
    private MauSacRepon repon = new MauSacRepon();
    private List<MauSac> listMS = new ArrayList<>();

    private MauSac mauSac = new MauSac();
    private TimeUtil timeUtil = new TimeUtil();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.contains("hien-thi")) {
            this.hienThi(request, response);
        } else if (uri.contains("view-add")) {
            this.viewAdd(request, response);
        } else if (uri.contains("update")) {
            this.viewUpdate(request, response);
        } else if (uri.contains("delete")) {
            this.delete(request, response);
        } else if (uri.contains("detail")) {
            this.detail(request, response);
        } else {
            this.hienThi(request, response);
        }
    }

    private void detail(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String ma = request.getParameter("ma");
        MauSac ms = repon.getMauSacByMa(ma);
        request.setAttribute("detailMauSac", ms);
        request.getRequestDispatcher("/view/admin/mauSac/detail-mau-sac.jsp").forward(request, response);
    }

    private void delete(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String ma = request.getParameter("ma");
        MauSac ms = repon.getMauSacByMa(ma);
        repon.delete(ms);
        response.sendRedirect("/mau-sac/hien-thi");
    }

    private void viewUpdate(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String ma = request.getParameter("ma");
        MauSac ms = repon.getMauSacByMa(ma);
        request.setAttribute("updateMauSac", ms);
        request.getRequestDispatcher("/view/admin/mauSac/update-mau-sac.jsp").forward(request, response);
    }

    private void viewAdd(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setAttribute("view_mau_sac", "view/admin/mauSac/add-mau-sac.jsp");
        request.getRequestDispatcher("/view/admin/mauSac/add-mau-sac.jsp").forward(request, response);
    }

    private void hienThi(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<MauSac> list = repon.getAll();
        request.setAttribute("listMauSac", list);
        request.getRequestDispatcher("/view/admin/mauSac/list-mau-sac.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.contains("add")) {
            this.add(request, response);
        } else if (uri.contains("update")) {
            this.update(request, response);
        } else if (uri.contains("search")) {
            this.search(request, response);
        }
    }

    private void search(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String tenMau = request.getParameter("tenMau");
        List<MauSac> listMSSearch = repon.searchMauSac(tenMau);
        System.out.println(listMSSearch);
        request.setAttribute("listMauSac", listMSSearch);
        request.getRequestDispatcher("/view/admin/mauSac/list-mau-sac.jsp").forward(request, response);
    }

    private void update(HttpServletRequest request, HttpServletResponse response) {
        try {
            String ma = request.getParameter("ma");
            System.out.println("Mã :" + ma);
            String ten = request.getParameter("ten");
            System.out.println("Tên :" + ten);
            String trangthai = request.getParameter("trangThai");
            System.out.println("Trạng thái : " + trangthai);
            // Kiểm tra các trường có rỗng không
            if (ma == null || ma.trim().isEmpty() || ten == null || ten.trim().isEmpty()) {
                request.getSession().setAttribute("mess_error", "Vui lòng không bỏ trống");
                response.sendRedirect("/mau-sac/update");
                return;
            } else {
            }

            MauSac ms = MauSac.builder()
                    .maMau(ma)
                    .tenMau(ten)
                    .trangThai(trangthai)
                    .ngaySua(TimeUtil.timeNow())
                    .build();
            // Gọi service để cập nhật màu sắc
            if (repon.update(ms, ma)) {
                request.getSession().setAttribute("mess-error", "Cập nhật thành công");
                response.sendRedirect("/mau-sac/hien-thi");
            } else {
                request.getSession().setAttribute("mess-error", "Cập nhật thất bại");
                response.sendRedirect("/mau-sac/update");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void add(HttpServletRequest request, HttpServletResponse response) {
        try {
            // Tạo mã tự sinh
            GenMaTuDong taoMa = new GenMaTuDong() {
                @Override
                public String maTuDong() {
                    //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                    int gen = new Random().nextInt(1000000);
                    return "MS" + gen;
                }
            };
            String ma = taoMa.maTuDong();
            System.out.println("Mã :" + ma);
            String ten = request.getParameter("ten");
            System.out.println("Tên :" + ten);
            String trangthai = request.getParameter("trangThai");
            System.out.println("Trạng thái : " + trangthai);
            String mess_error = "";

            // Kiểm tra các trường có rỗng không
            if (ten.trim().isEmpty()) {
                mess_error = "Vui lòng không bỏ trống tên";
            } else if (repon.getMauSacByMa(ma) != null) {
                mess_error = "Mã màu sắc đã tồn tại";
            } else {
                // Nếu thông tin hợp lệ, tiến hành thêm mới
                MauSac ms = MauSac.builder()
                        .maMau(ma)
                        .tenMau(ten)
                        .trangThai(trangthai)
                        .ngayTao(TimeUtil.timeNow())
                        .build();
                listMS.add(ms);
                if (repon.add(ms)) {
                    request.getSession().setAttribute("mess", "Thêm mới thành công");
                    response.sendRedirect("/mau-sac/hien-thi");
                    return;
                } else {
                    mess_error = "Thêm mới thất bại";
                }
            }
            request.getSession().setAttribute("mess_error", mess_error);
            response.sendRedirect("/mau-sac/view-add");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
