package controller.admin;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.ChiTietSanPham;
import model.HoaDon;
import model.HoaDonChiTiet;
import model.KhachHang;
import reponse.admin.BanHangRepository;
import reponse.admin.ChiTietSanPhamRepon;
import reponse.admin.HoaDonChiTietRepon;
import reponse.admin.HoaDonRepon;
import util.TimeUtil;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "BanHangServlet", value = {
        "/ban-hang",
        "/tao-hoa-don",
        "/search-sdt",
        "/get-san-pham",
        "/add-san-pham",
        "/update-san-pham",
        "/delete-ctsp",
        "/thanh-toan-hd",
})
public class BanHangServlet extends HttpServlet {
    ChiTietSanPhamRepon reponCTSP = new ChiTietSanPhamRepon();
    HoaDonRepon reponHD = new HoaDonRepon();
    BanHangRepository reponBH = new BanHangRepository();
    HoaDonChiTietRepon reponHDCT = new HoaDonChiTietRepon();

    List<KhachHang> listKH = new ArrayList<>();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.equals("/ban-hang")) {
            this.hienThi(request, response);
        } else if (uri.equals("/get-san-pham")) {
            this.chiTiet(request, response);
        } else if (uri.equals("/delete-ctsp")) {
            this.deleteCTSP(request, response);
        } else if (uri.equals("/thanh-toan-hd")) {
            this.thanhToan(request, response);
        }
    }

    private void thanhToan(HttpServletRequest request, HttpServletResponse response) throws IOException {
        if (request.getParameter("idKH") != null && request.getParameter("idHoaDon") != null) {
            Integer idKH = Integer.valueOf(request.getParameter("idKH"));
            System.out.println(idKH);
            Integer idHD = Integer.valueOf(request.getParameter("idHoaDon"));
            System.out.println(idHD);
            reponBH.thanhToanHoaDon(idHD, idKH);
            response.sendRedirect("/ban-hang");
//            this.saveForm(request, response);
        }
    }

    private void deleteCTSP(HttpServletRequest request, HttpServletResponse response) throws IOException {
        System.out.println("bat dau xoa");
        if (request.getParameter("idCTSP") != null && request.getParameter("idHDCT") != null) {
            Integer idCTSP = Integer.valueOf(request.getParameter("idCTSP"));
            System.out.println(idCTSP);
            Integer idHDCT = Integer.valueOf(request.getParameter("idHDCT"));
            System.out.println(idHDCT);
            reponBH.xoaSanPhamKhoiHoaDonChiTiet(idHDCT, idCTSP);
            this.saveForm(request, response);
        }
    }

    private void chiTiet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Nếu mà id ctsp khác null thì sẽ trả về hóa đơn chi tiết
        if (request.getParameter("id") != null) {
            List<HoaDonChiTiet> listHDCT = reponBH.getCTSPByIDCTSP(Integer.valueOf(request.getParameter("id")));
            System.out.println("Cái gì đây : " + listHDCT);
            request.setAttribute("listCTSP", listHDCT);
        }
        request.getRequestDispatcher("/view/admin/banHang/ban-hang.jsp").forward(request, response);
    }

    private void hienThi(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // Lấy ra chi tiết sản phẩm
        List<ChiTietSanPham> listCTSP = reponBH.getAllCTSP();

        // Set biến atb listCTSP
        request.setAttribute("listCTSP", listCTSP);

        // Lấy ra list hóa đơn
        List<HoaDon> listHD = reponHD.getListCTTT();

        // set tong tien cho hoa don
        for (HoaDon hdd : listHD) {
            if (reponHD.getTongTienByIdHoaDona(hdd.getIdHoaDon()) != null) {
                hdd.setTongTien(reponHD.getTongTienByIdHoaDona(hdd.getIdHoaDon()));
            }
        }
        //set biến atb cho listHD
        request.setAttribute("listHD", listHD);
        // Nếu mà id hóa đơn khác null thì sẽ trả về hóa đơn chi tiết
        if (request.getParameter("idHoaDon") != null) {
            List<HoaDonChiTiet> listHDCT = reponBH.getHoaDonChiTietByHoaDonId(Integer.valueOf(request.getParameter("idHoaDon")));
            request.setAttribute("listHDCT", listHDCT);
            HoaDon hd = reponBH.getHoaDonById(Integer.valueOf(request.getParameter("idHoaDon")));
            request.setAttribute("values", hd);
        }
        request.getRequestDispatcher("/view/admin/banHang/ban-hang.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.equals("/tao-hoa-don")) {
            System.out.println("doPost of /tao-hoa-don ");
            this.taoMoiHoaDon(request, response);
        } else if (uri.equals("/search-sdt")) {
            this.searchSDT(request, response);
        } else if (uri.equals("/add-san-pham")) {
            System.out.println("doPost of /add-san-pham");
            this.addsp(request, response);
        } else if (uri.equals("/update-san-pham")) {
            this.updatesp(request, response);
        }
    }

    private void taoMoiHoaDon(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HoaDon hoaDon = new HoaDon();
        String tenKH = request.getParameter("hoTen");
        System.out.println("Tên kh : " + tenKH);
        if (tenKH != null && !tenKH.isEmpty() && !tenKH.isBlank()) {
            System.out.println("Tên KH " + tenKH + "Đã được ghi nhận không null");
            KhachHang kh = new KhachHang();
            kh = reponBH.getIdByName(tenKH);
            System.out.println("Khach hang tao hd : " + kh.getHoTen() + " " + kh.getSdt());
            if (kh != null) {
                hoaDon.setKhachHang(kh);
                hoaDon.setSoDienThoai(kh.getSdt());
                hoaDon.setDiaChi(kh.getDiaChi());
            }
            hoaDon.setNgayTao(TimeUtil.timeNow());
            hoaDon.setNgaySua(TimeUtil.timeNow());
            hoaDon.setTrangThai("Chờ thanh toán");
            reponBH.saveOrUpdateHD(hoaDon);
            response.sendRedirect("/ban-hang");
        } else {
            KhachHang khMacDinh = reponBH.getKhachHangById(6);
            if (khMacDinh != null) {
                hoaDon.setKhachHang(khMacDinh);
            }
            hoaDon.setNgayTao(TimeUtil.timeNow());
            hoaDon.setNgaySua(TimeUtil.timeNow());
            hoaDon.setTrangThai("Chờ thanh toán");
            reponBH.saveOrUpdateHD(hoaDon);
            response.sendRedirect("/ban-hang");
        }

    }

    private void searchSDT(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        System.out.println("Bat đầu tìm");
        String sdt = request.getParameter("sdt");
        System.out.println("đây là sdt" + sdt);
        KhachHang khachHang = reponBH.searchKhachHangBySdt(sdt);
        request.setAttribute("khachHang", khachHang);
        System.out.println("day la ten kh : " + khachHang.getHoTen());
        hienThi(request, response);
    }

    private void addsp(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("Bat dau add sp");
        System.out.println(request.getParameter("idHoaDon"));
        System.out.println(request.getParameter("id"));
        if (request.getParameter("idHoaDon") != null && request.getParameter("id") != null) {
            int idHoaDon = Integer.parseInt(request.getParameter("idHoaDon"));
            int idCTSP = Integer.parseInt(request.getParameter("id"));
            int soLuong = 0;
            try {
                soLuong = Integer.parseInt(request.getParameter("soLuong"));
            } catch (Exception e) {
                alert("Số lượng phải là số!!", request);
                hienThi(request, response);
                return;
            }
            System.out.println("goi add");
            if (checkAddGioHang(request, response)) {
                reponBH.themSanPhamVaoHoaDonChiTiet(idHoaDon, idCTSP, soLuong);
                System.out.println("ahihi");
                List<HoaDonChiTiet> listHDCT = reponBH.getHoaDonChiTietByHoaDonId(idHoaDon);
                request.setAttribute("listHDCT", listHDCT);
                List<HoaDonChiTiet> listCTSP = reponBH.getCTSPByIDCTSP(idCTSP);
                request.setAttribute("listCTSP", listCTSP);
                saveForm(request, response);
            }
        } else {
            saveForm(request, response);
        }

    }

    private boolean checkAddGioHang(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("bat dau check");
        int soLuongThemVaoGio = Integer.valueOf(request.getParameter("soLuong"));
        System.out.println("soluong them vao gio : " + soLuongThemVaoGio);
        int soLuongTonSP = reponBH.getSoLuongTonByIDCTSP(Integer.valueOf(request.getParameter("id")));
        System.out.println(Integer.valueOf(request.getParameter("id")));
        int soLuongTrongGio = reponBH.getSoLuongTrongGioHangByIdCTSP(Integer.valueOf(request.getParameter("id")));
        System.out.println(Integer.valueOf(request.getParameter("id")));
        try {
            int soLuongTon = soLuongTrongGio + soLuongTonSP;
            System.out.println("so luong ton : " + soLuongTon);
            if (soLuongThemVaoGio < 1) {
                alert2("Số lượng phải lớn hơn 0!!", request);
                System.out.println("cbi tra ve ne hihi");
                hienThi(request, response);
                System.out.println("tra ve rui ne hehe");
                return false;
            } else if (soLuongThemVaoGio > soLuongTon) {
                System.out.println("bat dau check so luong ton");
                alert("Số lượng tồn không đủ!!", request);
                System.out.println("tra ve ne hihi");
                hienThi(request, response);
                return false;
            }
        } catch (Exception e) {
            alert2("Số lượng phải là số!!", request);
            hienThi(request, response);
            e.printStackTrace();
            return false;
        }
        return true;
    }

    private void alert2(String alert, HttpServletRequest request) {
        request.setAttribute("error2", "<div class=\"alert alert-danger\" role=\"alert\">\n"
                + alert + " \n" +
                "</div>");
    }

    private void updatesp(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        if (request.getParameter("idCTSP") != null && request.getParameter("idHDCT") != null && request.getParameter("soLuongThayDoi") != null && !request.getParameter("soLuongThayDoi").isEmpty()) {
//            int soLuongTon = reponBH.getSoLuongTonByIDCTSP(Integer.valueOf(request.getParameter("idCTSP")));
//            int idHoaDon = Integer.parseInt(request.getParameter("idHoaDon"));
            int idCTSP = Integer.parseInt(request.getParameter("idCTSP"));
            int idHDCT = Integer.parseInt(request.getParameter("idHDCT"));
            int soLuongThayDoi = 0;
            try {
                soLuongThayDoi = Integer.parseInt(request.getParameter("soLuongThayDoi"));
            } catch (Exception e) {
                alert("Số lượng phải là số!!", request);
                hienThi(request, response);
                return;
            }

            int soLuongTrongGio = Integer.parseInt(request.getParameter("soLuongTrongGio"));
            if (checkUpdateGioHang(request, response)) {
                reponBH.capNhatSanPhamTrongGioHang(idCTSP, idHDCT, soLuongThayDoi, soLuongTrongGio);
                saveForm(request, response);
            }
        } else {
            saveForm(request, response);

        }

    }


    private void alert(String alert, HttpServletRequest request) {
        request.setAttribute("error1", "<div class=\"alert alert-danger\" role=\"alert\">\n"
                + alert + " \n" +
                "</div>");
    }

    private boolean checkUpdateGioHang(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {
        int soLuongThayDoi;

        int soLuongTonSP = reponBH.getSoLuongTonByIDCTSP(Integer.valueOf(request.getParameter("idCTSP")));
        int soLuongTrongGio = Integer.parseInt(request.getParameter("soLuongTrongGio"));
        int soLuongTon = soLuongTonSP + soLuongTrongGio;
        try {
            soLuongThayDoi = Integer.parseInt(request.getParameter("soLuongThayDoi"));
            if (soLuongThayDoi < 1) {
                alert("Số lượng phải lớn hơn 0!!", request);
                hienThi(request, resp);
                return false;
            } else if (soLuongThayDoi > soLuongTon) {
                alert("Số tồn không đủ!!", request);
                hienThi(request, resp);
                return false;
            }
        } catch (Exception e) {
            alert("Số lượng phải là số!!", request);
            hienThi(request, resp);
            e.printStackTrace();
            return false;
        }
        return true;
    }


//    private void taoMoiHoaDon(HttpServletRequest request, HttpServletResponse response) throws IOException {
//        HoaDon hoaDon = new HoaDon();
//        String tenKH = request.getParameter("hoTen");
//        System.out.println("day la ten : " + tenKH);
//        if (tenKH != null && !tenKH.isEmpty()) {
//            System.out.println("Bat dau lay ten khach hang");
//            KhachHang kh = reponBH.getIdByName(tenKH);
//            System.out.println("Khach hang tao hd : " + reponBH.getIdByName(tenKH));
//            if (kh != null) {
//                hoaDon.setKhachHang(kh);
//                hoaDon.setSoDienThoai(kh.getSdt()); // Kiểm tra kh != null trước khi sử dụng
//                System.out.println("Day la sdt : " + kh.getSdt());
//                hoaDon.setDiaChi(kh.getDiaChi()); // Kiểm tra kh != null trước khi sử dụng
//                System.out.println("Day la dia chi : " + kh.getDiaChi());
//            }
//            hoaDon.setNgayTao(TimeUtil.timeNow());
//            hoaDon.setNgaySua(TimeUtil.timeNow());
//            hoaDon.setTrangThai("Chờ thanh toán");
//            reponBH.saveOrUpdateHD(hoaDon);
//            response.sendRedirect("/ban-hang");
//        } else {
//            KhachHang khMacDinh = reponBH.getKhachHangById(6);
//            if (khMacDinh != null) {
//                hoaDon.setKhachHang(khMacDinh);
//            }
//            hoaDon.setNgayTao(TimeUtil.timeNow());
//            hoaDon.setNgaySua(TimeUtil.timeNow());
//            hoaDon.setTrangThai("Chờ thanh toán");
//            reponBH.saveOrUpdateHD(hoaDon);
//            response.sendRedirect("/ban-hang");
//        }
//    }


    private void saveForm(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.sendRedirect(req.getContextPath() + "/ban-hang?idHoaDon=" + req.getParameter("idHoaDon"));
    }

}
