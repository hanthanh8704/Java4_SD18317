package controller.admin;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.HoaDon;
import model.Size;
import reponse.admin.SizeRepon;
import util.GenMaTuDong;
import util.TimeUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@WebServlet(name = "CuaHangServlet", value = {
        "/size/hien-thi",
        "/size/add",
        "/size/update",
        "/size/view-add",
        "/size/detail",
        "/size/delete",
        "/search-size",
})
public class SizeServlet extends HttpServlet {

    private SizeRepon repon = new SizeRepon(); // Đối tượng dùng để thực hiện các thao tác với cơ sở dữ liệu
    private List<Size> list = new ArrayList<>(); // Danh sách để lưu trữ dữ liệu tạm thời

    private TimeUtil timeUtil = new TimeUtil(); // Đối tượng dùng để lấy thời gian hiện tại

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if(uri.contains("hien-thi")){
            this.hienThi(request,response); // Hiển thị danh sách các size
        }else if(uri.contains("view-add")){
            this.viewAdd(request,response); // Hiển thị giao diện thêm mới size
        }else if(uri.contains("update")){
            this.viewUpdate(request,response); // Hiển thị giao diện cập nhật size
        } else if (uri.contains("delete")) {
            this.delete(request,response); // Xóa size
        } else if (uri.contains("detail")) {
            this.detail(request,response); // Xem chi tiết size
        }else {
            this.hienThi(request,response); // Mặc định hiển thị danh sách size
        }
    }

    private void detail(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String ma = request.getParameter("ma");
        Size size = repon.getKichCoByMa(ma); // Lấy size dựa trên mã
        System.out.println(size);
        request.setAttribute("detailSize",size);
        request.getRequestDispatcher("/view/admin/kichCo/detail-kich-co.jsp").forward(request,response);
    }

    private void delete(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String ma = request.getParameter("ma");
        Size size = repon.getKichCoByMa(ma); // Lấy size dựa trên mã
        repon.delete(size); // Xóa size
        response.sendRedirect("/size/hien-thi"); // Redirect về trang hiển thị
    }

    private void viewUpdate(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String ma = request.getParameter("ma");
        Size size = repon.getKichCoByMa(ma);
        request.setAttribute("updateSize", size);
        request.getRequestDispatcher("/view/admin/kichCo/update-kich-co.jsp").forward(request, response); // Hiển thị giao diện cập nhật size
    }

    private void viewAdd(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setAttribute("addSize","/view/admin/kichCo/add-kich-co.jsp");
        request.getRequestDispatcher("/view/admin/kichCo/add-kich-co.jsp").forward(request,response); // Hiển thị giao diện thêm mới size
    }

    private void hienThi(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Size> listSize = repon.getAll(); // Lấy danh sách tất cả các size
        request.setAttribute("listSize",listSize);
        request.getRequestDispatcher("/view/admin/kichCo/list-kich-co.jsp").forward(request,response); // Hiển thị danh sách size
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if(uri.contains("add")){
            this.add(request,response); // Thêm mới size
        } else if (uri.contains("update")) {
            this.update(request,response); // Cập nhật size
        } else if (uri.contains("/search-size")) {
            this.search(request,response);
        }
    }

    private void search(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("txt");
        String ma = request.getParameter("txt");
        List<Size> list = repon.searchSizebyNamebyMa(name,ma);
        request.setAttribute("listSize",list);
        request.setAttribute("txtSearch",name);
        request.setAttribute("txtSearch",ma);
        request.getRequestDispatcher("/view/admin/kichCo/list-kich-co.jsp").forward(request,response);
    }

    private void update(HttpServletRequest request, HttpServletResponse response) {
        try {
            String ma = request.getParameter("ma");
            System.out.println("Mã :" + ma);
            String ten = request.getParameter("ten");
            System.out.println("Tên :" + ten);
            String trangThai = request.getParameter("trangThai");
            System.out.println("Trạng thái : " + trangThai);
            if (ma == null || ma.trim().isEmpty() || ten == null || ten.trim().isEmpty()) {
                request.getSession().setAttribute("mess_error", "Vui lòng không bỏ trống");
                response.sendRedirect("/size/update");
                return;
            }
            // Tạo một bản sao của đối tượng MauSac sử dụng Builder Pattern
            Size s = Size.builder()
                    .maSize(ma)
                    .tenSize(ten)
                    .trangThai(trangThai)
                    .ngaySua(TimeUtil.timeNow())
                    .build();
            // Gọi service để cập nhật màu sắc
            if (repon.update(s, ma)) {
                request.getSession().setAttribute("mess", "Cập nhật thành công");
                response.sendRedirect("/size/hien-thi");
            } else {
                request.getSession().setAttribute("mess-error", "Cập nhật thất bại");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void add(HttpServletRequest request, HttpServletResponse response) {
        try {
            // Tạo mã tự động
            GenMaTuDong taoMa = new GenMaTuDong() {
                @Override
                public String maTuDong() {
                    int gen = new Random().nextInt(1000000);
                    return "KC" + gen;
                }
            };
            String ma = taoMa.maTuDong(); // Tạo mã mới
            String ten = request.getParameter("ten");
            String trangThai = request.getParameter("trangThai");
            if(ten.trim().isEmpty()){
                request.getSession().setAttribute("mess_error","Vui lòng không bỏ trống tên");
                response.sendRedirect("/size/view-add");
                return;
            }
            Size size = Size.builder()
                    .maSize(ma)
                    .tenSize(ten)
                    .trangThai(trangThai)
                    .ngayTao(TimeUtil.timeNow())
                    .build();
            list.add(size);
            if(repon.add(size)){
                request.getSession().setAttribute("mess","Them moi thanh cong");
                response.sendRedirect("/size/hien-thi");
            }else {
                request.getSession().setAttribute("mess-error","Them moi that bai");
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
