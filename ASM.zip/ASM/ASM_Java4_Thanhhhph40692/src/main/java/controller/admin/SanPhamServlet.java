package controller.admin;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.DanhMuc;
import model.SanPham;
import model.Size;
import org.hibernate.Session;
import org.hibernate.query.Query;
import reponse.admin.DanhMucRepon;
import reponse.admin.SanPhamRepon;
import util.GenMaTuDong;
import util.HibernateUtil;
import util.TimeUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@WebServlet(name = "SanPhamServlet", value = {
        "/san-pham/hien-thi",
        "/san-pham/add",
        "/san-pham/update",
        "/san-pham/view-add",
        "/san-pham/detail",
        "/san-pham/delete",
})
public class SanPhamServlet extends HttpServlet {
    List<SanPham> listSP = new ArrayList<>();
    private DanhMucRepon reponDanhMuc = new DanhMucRepon();
    private SanPhamRepon reponSanPham = new SanPhamRepon();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String url = request.getRequestURI();
        if (url.contains("hien-thi")) {
            this.hienThi(request, response); // Hiển thị danh sách các size
        } else if (url.contains("view-add")) {
            this.viewAdd(request, response); // Hiển thị giao diện thêm mới size
        } else if (url.contains("update")) {
            this.viewUpdate(request, response); // Hiển thị giao diện cập nhật size
        } else if (url.contains("delete")) {
            this.delete(request, response); // Xóa size
        } else if (url.contains("detail")) {
            this.detail(request, response); // Xem chi tiết size
        } else {
            this.hienThi(request, response); // Mặc định hiển thị danh sách size
        }
    }

    private void detail(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String ma = request.getParameter("ma");
        // lấy ra danh mục
        List<DanhMuc> listDanhMuc = reponDanhMuc.getAll();
        request.setAttribute("listDanhMuc", listDanhMuc);
        // Lấy ra sản phẩm
        SanPham sanPham = reponSanPham.getSanPhamByMa(ma);
        request.setAttribute("detailSanPham", sanPham);
        request.getRequestDispatcher("/view/admin/sanPham/detail-san-pham.jsp").forward(request, response); // Chuyển tiếp đến trang JSP
    }

    private void delete(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String ma = request.getParameter("ma");
        SanPham sanPham = reponSanPham.getSanPhamByMa(ma);
        reponSanPham.delete(sanPham);
        response.sendRedirect("/san-pham/hien-thi");
    }

    private void viewUpdate(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String ma = request.getParameter("ma");

        List<DanhMuc> listDanhMuc = reponDanhMuc.getAll();
        request.setAttribute("listDanhMuc", listDanhMuc);

        SanPham sanPham = reponSanPham.getSanPhamByMa(ma);
        request.setAttribute("updateSanPham", sanPham);
        request.getRequestDispatcher("/view/admin/sanPham/update-san-pham.jsp").forward(request, response);
    }

    private void viewAdd(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<DanhMuc> listDanhMuc = reponDanhMuc.getAll();
        request.setAttribute("listDanhMuc", listDanhMuc);
        request.setAttribute("addSize", "/view/admin/sanPham/add-san-pham.jsp");
        request.getRequestDispatcher("/view/admin/sanPham/add-san-pham.jsp").forward(request, response); // Hiển thị giao diện thêm mới size
    }

    private void hienThi(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("*** do get of /san-pham/hien-thi");
        List<SanPham> listSanPham = reponSanPham.getAll();
        request.setAttribute("listSanPham", listSanPham);
        request.getRequestDispatcher("/view/admin/sanPham/list-san-pham.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.contains("add")) {
            this.add(request, response); // Thêm mới size
        } else if (uri.contains("update")) {
            this.update(request, response); // Cập nhật size
        } else if (uri.contains("/san-pham/search")) {
            this.search(request,response);
        }
    }

    private void update(HttpServletRequest request, HttpServletResponse response) {
        try{
            String ma = request.getParameter("ma");
            String ten = request.getParameter("ten");
            String trangThai = request.getParameter("trangThai");
            Integer idDanhMuc = Integer.valueOf(request.getParameter("danhMuc"));
            if(ma.trim().isEmpty() || ten.trim().isEmpty()){
                request.getSession().setAttribute("mess_error", "Vui lòng không bỏ trống");
                response.sendRedirect("/san-pham/update");
                return;
            }
            // Tạo đối tượng Danh Mục
            DanhMuc danhMuc = new DanhMuc();
            danhMuc.setId(idDanhMuc);
            // Tạo đối tượng Sản Phẩm
            SanPham sanPham = SanPham.builder()
                    .maSanPham(ma)
                    .tenSanPham(ten)
                    .trangThai(trangThai)
                    .danhMuc(danhMuc)
                    .ngaySua(TimeUtil.timeNow())
                    .build();
            if(reponSanPham.update(sanPham,ma)){
                request.getSession().setAttribute("mess", "Cap nhat thanh cong");
                response.sendRedirect("/san-pham/hien-thi");
            } else {
                request.getSession().setAttribute("mess-error", "Cap nhat that bai");
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private void add(HttpServletRequest request, HttpServletResponse response) {
        try {
            // Tạo mã tự động
            GenMaTuDong taoMa = new GenMaTuDong() {
                @Override
                public String maTuDong() {
                    int gen = new Random().nextInt(1000000);
                    return "SP" + gen;
                }
            };
            String ma = taoMa.maTuDong(); // Tạo mã mới
            System.out.println(ma);
            String ten = request.getParameter("ten");
            System.out.println(ten);
            String trangThai = request.getParameter("trangThai");
            System.out.println(trangThai);
            Integer idDanhMuc = Integer.valueOf(request.getParameter("danhMuc"));
            System.out.println(idDanhMuc);
            // Tạo đối tượng Danh Mục
            DanhMuc danhMuc = new DanhMuc();
            danhMuc.setId(idDanhMuc);
            // Tạo đối tượng Sản Phẩm
            SanPham sanPham = SanPham.builder()
                    .maSanPham(ma)
                    .tenSanPham(ten)
                    .trangThai(trangThai)
                    .danhMuc(danhMuc)
                    .ngayTao(TimeUtil.timeNow())
                    .build();
            // Thêm sản phẩm vào danh sách và repository
            listSP.add(sanPham);
            if (reponSanPham.add(sanPham)) {
                request.getSession().setAttribute("mess", "Thêm mới thành công");
                response.sendRedirect("/san-pham/hien-thi");
            } else {
                request.getSession().setAttribute("mess-error", "Thêm mới thất bại");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void search(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("txt");
        String ma = request.getParameter("txt");
        List<SanPham> list = reponSanPham.searchSanPhambyNamebyMa(name,ma);
        request.setAttribute("listSanPham",list);
        request.setAttribute("txtSearch",name);
        request.setAttribute("txtSearch",ma);
        request.getRequestDispatcher("/view/admin/sanPham/list-san-pham.jsp").forward(request, response);
    }
}
