package controller.admin;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.KhachHang;
import reponse.admin.KhachHangRepon;
import util.TimeUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "KhachHangServlet", value = {
        "/khach-hang/hien-thi",
        "/khach-hang/add",
        "/khach-hang/view-add",
        "/khach-hang/update",
        "/khach-hang/detail",
        "/khach-hang/delete",
        "/khach-hang/search-kh",
})
public class KhachHangServlet extends HttpServlet {
    private List<KhachHang> listKH = new ArrayList<>();
    private KhachHangRepon repon = new KhachHangRepon();
    private TimeUtil timeUtil = new TimeUtil();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if(uri.contains("/khach-hang/hien-thi")){
            this.hienThi(request,response);
        } else if (uri.contains("/khach-hang/view-add")) {
            this.viewAdd(request,response);
        } else if (uri.contains("/khach-hang/update")) {
            this.viewUpdate(request,response);
        } else if (uri.contains("/khach-hang/delete")) {
            this.delete(request,response);
        } else if (uri.contains("/khach-hang/detail")) {
            this.detail(request,response);
        } else {
            this.hienThi(request,response);
        }
    }

    private void detail(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Integer id = Integer.valueOf(request.getParameter("id"));
        KhachHang kh = repon.getKhachHangById(id);
        request.setAttribute("detailKhachHang",kh);
        request.getRequestDispatcher("/view/admin/khachHang/detail-khach-hang.jsp").forward(request,response);
    }

    private void delete(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Integer id = Integer.valueOf(request.getParameter("id"));
        KhachHang kh = repon.getKhachHangById(id);
        repon.delete(kh);
        response.sendRedirect("/khach-hang/hien-thi");
    }

    private void viewUpdate(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Integer id = Integer.valueOf(request.getParameter("id"));
        KhachHang kh = repon.getKhachHangById(id);
        request.setAttribute("updateKhachHang",kh);
        request.getRequestDispatcher("/view/admin/khachHang/update-khach-hang.jsp").forward(request,response);
    }

    private void viewAdd(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setAttribute("addKhachHang","/view/admin/khachHang/add-khach-hang.jsp");
        request.getRequestDispatcher("/view/admin/khachHang/add-khach-hang.jsp").forward(request,response);
    }

    private void hienThi(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<KhachHang> listKH = repon.getAll();
        System.out.println(listKH.size());
        request.setAttribute("listKH",listKH);
        request.getRequestDispatcher("/view/admin/khachHang/list-khach-hang.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if(uri.contains("add")){
            this.add(request,response); // Thêm mới size
        } else if (uri.contains("update")) {
            this.update(request,response); // Cập nhật size
        } else if (uri.contains("/khach-hang/search-kh")) {
            this.search(request,response);
        }
    }

    private void search(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("txt");
        String diaChi = request.getParameter("txt");
        String sdt = request.getParameter("txt");
        List<KhachHang> list = repon.searchSizebyNamebySDTbyDiaChi(name,diaChi,sdt);
        request.setAttribute("listKH",list);
        request.setAttribute("txtSearch",name);
        request.setAttribute("txtSearch",diaChi);
        request.setAttribute("txtSearch",sdt);
        request.getRequestDispatcher("/view/admin/khachHang/list-khach-hang.jsp").forward(request,response);
    }

    private void update(HttpServletRequest request, HttpServletResponse response) {
        try{
            Integer id = Integer.valueOf(request.getParameter("id"));
            String hoTen = request.getParameter("hoTen");
            String diaChi = request.getParameter("diaChi");
            String sdt = request.getParameter("sdt");
            String trangThai = request.getParameter("trangThai");

            KhachHang khachHang = KhachHang.builder()
                    .hoTen(hoTen)
                    .diaChi(diaChi)
                    .sdt(sdt)
                    .trangThai(trangThai)
                    .ngaySua(TimeUtil.timeNow())
                    .build();
            repon.update(khachHang,id);
            response.sendRedirect("/khach-hang/hien-thi");
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private void add(HttpServletRequest request, HttpServletResponse response) {
        try {
            String hoTen = request.getParameter("hoTen");
            String diaChi = request.getParameter("diaChi");
            String sdt = request.getParameter("sdt");
            String trangThai = request.getParameter("trangThai");

            KhachHang khachHang = KhachHang.builder()
                    .hoTen(hoTen)
                    .diaChi(diaChi)
                    .sdt(sdt)
                    .trangThai(trangThai)
                    .ngayTao(TimeUtil.timeNow())
                    .build();
            listKH.add(khachHang);
            if(repon.add(khachHang)){
                request.getSession().setAttribute("mess","Them moi thanh cong");
                response.sendRedirect("/khach-hang/hien-thi");
            }else {
                request.getSession().setAttribute("mess-error","Them moi that bai");
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
