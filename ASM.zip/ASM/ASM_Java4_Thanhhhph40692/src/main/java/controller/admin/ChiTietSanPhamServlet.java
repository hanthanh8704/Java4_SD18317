package controller.admin;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.*;
import reponse.admin.ChiTietSanPhamRepon;
import reponse.admin.MauSacRepon;
import reponse.admin.SanPhamRepon;
import reponse.admin.SizeRepon;
import util.TimeUtil;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "ChiTietSanPhamServlet", value = {
        "/chi-tiet-san-pham/hien-thi",
        "/chi-tiet-san-pham/add",
        "/chi-tiet-san-pham/update",
        "/chi-tiet-san-pham/view-add",
        "/chi-tiet-san-pham/detail",
        "/chi-tiet-san-pham/delete",
        "/chi-tiet-san-pham/search",
        "/chi-tiet-san-pham/search-gia",
})
public class ChiTietSanPhamServlet extends HttpServlet {
    List<ChiTietSanPham> listCTSP = new ArrayList<>();
    private SanPhamRepon reponSanPham = new SanPhamRepon();
    private MauSacRepon reponMauSac = new MauSacRepon();
    private SizeRepon reponSize = new SizeRepon();

    private ChiTietSanPhamRepon reponCTSP = new ChiTietSanPhamRepon();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String url = request.getRequestURI();
        if (url.contains("hien-thi")) {
            this.hienThi(request, response); // Hiển thị danh sách các size
        } else if (url.contains("view-add")) {
            this.viewAdd(request, response); // Hiển thị giao diện thêm mới size
        } else if (url.contains("update")) {
            this.viewUpdate(request, response); // Hiển thị giao diện cập nhật size
        } else if (url.contains("delete")) {
            this.delete(request, response); // Xóa size
        } else if (url.contains("detail")) {
            this.detail(request, response); // Xem chi tiết size
        } else {
            this.hienThi(request, response); // Mặc định hiển thị danh sách size
        }
        // Lấy ra sản phẩm
        List<SanPham> listSanPham = reponSanPham.getAll();
        request.setAttribute("listSanPham", listSanPham);
        // Lấy ra size
        List<Size> listSize = reponSize.getAll();
        request.setAttribute("listSize", listSize);
        // Lấy ra màu sắc
        List<MauSac> listMauSac = reponMauSac.getAll();
        request.setAttribute("listMauSac", listMauSac);
    }

    private void detail(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Lấy ra sản phẩm
        List<SanPham> listSanPham = reponSanPham.getAll();
        request.setAttribute("listSanPham", listSanPham);
        // Lấy ra size
        List<Size> listSize = reponSize.getAll();
        request.setAttribute("listSize", listSize);
        // Lấy ra màu sắc
        List<MauSac> listMauSac = reponMauSac.getAll();
        request.setAttribute("listMauSac", listMauSac);
        //
        Integer id = Integer.valueOf(request.getParameter("id"));
        ChiTietSanPham ctsp = reponCTSP.getChiTietSanPhamByMa(id);
        request.setAttribute("detailCTSP", ctsp);
        request.getRequestDispatcher("/view/admin/chiTietSanPham/detail-ctsp.jsp").forward(request, response);
    }

    private void delete(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Integer id = Integer.valueOf(request.getParameter("id"));
        ChiTietSanPham ctsp = reponCTSP.getChiTietSanPhamByMa(id);
        reponCTSP.delete(ctsp);
        response.sendRedirect("/chi-tiet-san-pham/hien-thi");
    }

    private void viewUpdate(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Integer id = Integer.valueOf(request.getParameter("id"));
        ChiTietSanPham ctsp = reponCTSP.getChiTietSanPhamByMa(id);

        // Lấy ra sản phẩm
        List<SanPham> listSanPham = reponSanPham.getAll();
        request.setAttribute("listSanPham", listSanPham);
        // Lấy ra size
        List<Size> listSize = reponSize.getAll();
        request.setAttribute("listSize", listSize);
        // Lấy ra màu sắc
        List<MauSac> listMauSac = reponMauSac.getAll();
        request.setAttribute("listMauSac", listMauSac);

        request.setAttribute("updateCTSP", ctsp);
        request.getRequestDispatcher("/view/admin/chiTietSanPham/update-ctsp.jsp").forward(request, response);
    }

    private void viewAdd(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Lấy ra sản phẩm
        List<SanPham> listSanPham = reponSanPham.getAll();
        request.setAttribute("listSanPham", listSanPham);
        // Lấy ra size
        List<Size> listSize = reponSize.getAll();
        request.setAttribute("listSize", listSize);
        // Lấy ra màu sắc
        List<MauSac> listMauSac = reponMauSac.getAll();
        request.setAttribute("listMauSac", listMauSac);
        request.setAttribute("addCTSP", "/view/admin/chiTietSanPham/add-ctsp.jsp");
        request.getRequestDispatcher("/view/admin/chiTietSanPham/add-ctsp.jsp").forward(request, response);
    }

    private void hienThi(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            List<ChiTietSanPham> listCTSP = reponCTSP.getAll();
            request.setAttribute("listCTSP", listCTSP);
            request.getRequestDispatcher("/view/admin/chiTietSanPham/list-ctsp.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.contains("/chi-tiet-san-pham/add")) {
            this.add(request, response);
        } else if (uri.contains("/chi-tiet-san-pham/update")) {
            this.update(request, response);
        } else if (uri.contains("/chi-tiet-san-pham/search-gia")) {
            this.searchGia(request, response);
        } else if (uri.contains("/chi-tiet-san-pham/search")) {
            this.search(request,response);
        }
    }

    private void search(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String tenMau = request.getParameter("txt");
        String tenSanPham = request.getParameter("txt");
        String tenSize = request.getParameter("txt");
        List<ChiTietSanPham> list = reponCTSP.searchCTSPbyMauSizeSP(tenMau,tenSanPham,tenSize);
        request.setAttribute("listCTSP",list);
        request.setAttribute("txtSearch",tenSanPham);
        request.setAttribute("txtSearch",tenMau);
        request.setAttribute("txtSearch",tenSize);
        request.getRequestDispatcher("/view/admin/chiTietSanPham/list-ctsp.jsp").forward(request, response);
    }

    private void searchGia(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        double frompriceValue = Double.parseDouble(request.getParameter("fromprice"));
        double topriceValue = Double.parseDouble(request.getParameter("toprice"));
        BigDecimal fromprice = BigDecimal.valueOf(frompriceValue);
        BigDecimal toprice = BigDecimal.valueOf(topriceValue);
        request.setAttribute("listCTSP", reponCTSP.search(fromprice, toprice));
        request.getRequestDispatcher("/view/admin/chiTietSanPham/list-ctsp.jsp").forward(request, response);
    }

    private void update(HttpServletRequest request, HttpServletResponse response) {
        try {
            Integer id = Integer.valueOf(request.getParameter("id"));
            Integer idSanPham = Integer.valueOf(request.getParameter("sanPham"));
            Integer idMauSac = Integer.valueOf(request.getParameter("mauSac"));
            Integer idKichCo = Integer.valueOf(request.getParameter("kichCo"));
            // Chuyển đổi String sang BigDecimal
            BigDecimal giaBan = null;
            try {
                giaBan = BigDecimal.valueOf(Double.parseDouble(request.getParameter("giaBan")));
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
            Integer soLuong = Integer.valueOf(request.getParameter("soLuongTon"));
            String trangThai = request.getParameter("trangThai");

            // Kiểm tra xem ID có được sửa đổi không
            Integer newId = Integer.valueOf(request.getParameter("id"));
            if (!id.equals(newId)) {
                response.sendRedirect("/chi-tiet-san-pham/update");
            }

            // Tạo đối tượng Sản Phẩm
            SanPham sp = new SanPham();
            sp.setId(idSanPham);
            // Tạo đối tượng màu sắc
            MauSac ms = new MauSac();
            ms.setId(idMauSac);
            // Tạo đối tượng kích cỡ
            Size s = new Size();
            s.setId(idKichCo);
            // Tạo đối tượng SanPhamCT
            ChiTietSanPham ctsp = ChiTietSanPham.builder()
                    .sanPham(sp)
                    .mauSac(ms)
                    .size(s)
                    .giaBan(giaBan)
                    .soLuongTon(soLuong)
                    .trangThai(trangThai)
                    .ngayTao(TimeUtil.timeNow())
                    .build();
            reponCTSP.update(ctsp, id);
            response.sendRedirect("/chi-tiet-san-pham/hien-thi");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void add(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Integer idSanPham = Integer.valueOf(request.getParameter("sanPham"));
        Integer idMauSac = Integer.valueOf(request.getParameter("mauSac"));
        Integer idKichCo = Integer.valueOf(request.getParameter("kichCo"));
        // Chuyển đổi String sang BigDecimal
        BigDecimal giaBan = null;
        try {
            giaBan = BigDecimal.valueOf(Double.parseDouble(request.getParameter("giaBan")));
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        Integer soLuong = Integer.valueOf(request.getParameter("soLuongTon"));
        String trangThai = request.getParameter("trangThai");
        // Tạo đối tượng Sản Phẩm
        SanPham sp = new SanPham();
        sp.setId(idSanPham);
        // Tạo đối tượng màu sắc
        MauSac ms = new MauSac();
        ms.setId(idMauSac);
        // Tạo đối tượng kích cỡ
        Size s = new Size();
        s.setId(idKichCo);
        // Tạo đối tượng SanPhamCT
        ChiTietSanPham ctsp = ChiTietSanPham.builder()
                .sanPham(sp)
                .mauSac(ms)
                .size(s)
                .giaBan(giaBan)
                .soLuongTon(soLuong)
                .trangThai(trangThai)
                .ngayTao(TimeUtil.timeNow())
                .build();
        listCTSP.add(ctsp);
        if (reponCTSP.add(ctsp)) {
            request.getSession().setAttribute("mess", "Thêm mới thành công");
            response.sendRedirect("/chi-tiet-san-pham/hien-thi");
        } else {
            request.getSession().setAttribute("mess-error", "Thêm mới thất bại");
        }
    }
}
