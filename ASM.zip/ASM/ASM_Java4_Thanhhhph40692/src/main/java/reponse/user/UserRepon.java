package reponse.user;
import model.ChiTietSanPham;
import model.DanhMuc;
import model.SanPham;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import util.HibernateUtil;

import java.util.ArrayList;
import java.util.List;
public class UserRepon {
    public List<ChiTietSanPham> getAllProduct(){
        List<ChiTietSanPham> listCTSP = new ArrayList<>();
        try(Session session = HibernateUtil.getFACTORY().openSession()){
            Query<ChiTietSanPham> query = session.createQuery("SELECT ctsp FROM ChiTietSanPham ctsp", ChiTietSanPham.class);
            listCTSP = query.getResultList();
        }catch (Exception e){
            e.printStackTrace();
        }
        return listCTSP;
    }

    // Hàm này dùng để lấy ra biến sản phẩm
    public List<SanPham> getAllCategory(){
        List<SanPham> list = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            // try vấn sql
            Query<SanPham> query = session.createQuery("SELECT sp FROM SanPham sp", SanPham.class);
            // lấy kq vừa truy vấn được cho danh sách
            list = query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Hàm này dùng để lấy ra id của sản phẩm
    public List<ChiTietSanPham> getChiTietSanPhamById(Integer id){
        List<ChiTietSanPham> list = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query<ChiTietSanPham> query = session.createQuery("SELECT ctsp FROM ChiTietSanPham ctsp WHERE ctsp.sanPham.id = :id", ChiTietSanPham.class);
            query.setParameter("id", id);
            list = query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Hàm lấy ra sản phẩm mới nhất
    public ChiTietSanPham getSanPhamNew() {
        ChiTietSanPham chiTietSanPham = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query<ChiTietSanPham> query = session.createQuery("SELECT ctsp FROM ChiTietSanPham ctsp ORDER BY ctsp.id DESC", ChiTietSanPham.class);
            query.setMaxResults(1); // Limit the result to 1 row
            chiTietSanPham = query.uniqueResult();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return chiTietSanPham;
    }

    // Hàm này dùng để lấy ra được detail của sản phẩm
    public ChiTietSanPham getDetailChiTietSanPhamById(Integer id){
        ChiTietSanPham chiTietSanPham = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query<ChiTietSanPham> query = session.createQuery("SELECT ctsp FROM ChiTietSanPham ctsp WHERE ctsp.id =: id", ChiTietSanPham.class);
            query.setParameter("id", id);
            chiTietSanPham = query.uniqueResult();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return chiTietSanPham;
    }

    // Hàm này dùng để lấy ra danh sách sản phẩm khi tìm kiếm
    public List<ChiTietSanPham> searchChiTietSanPhamByName(String name){
        List<ChiTietSanPham> list = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query<ChiTietSanPham> query = session.createQuery("SELECT ctsp FROM ChiTietSanPham ctsp WHERE ctsp.sanPham.tenSanPham LIKE :name", ChiTietSanPham.class);
            query.setParameter("name", "%" + name + "%");
            list = query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Hàm dùng để xóa sp
    public boolean delete(Integer id) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            transaction = session.beginTransaction();
            ChiTietSanPham chiTietSanPham = session.get(ChiTietSanPham.class, id);
            if (chiTietSanPham != null) {
                session.delete(chiTietSanPham);
                transaction.commit();
                return true;
            } else {
                System.out.println("Không tìm thấy sản phẩm có ID = " + id);
            }
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
        return false;
    }

}
