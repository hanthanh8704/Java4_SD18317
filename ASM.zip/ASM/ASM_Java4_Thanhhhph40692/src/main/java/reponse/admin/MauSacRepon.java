package reponse.admin;

import model.MauSac;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import util.HibernateUtil;

import java.util.ArrayList;
import java.util.List;

public class MauSacRepon {
    public List<MauSac> getAll(){
        // Tạo một danh sách để lưu trữ kết quả
        List<MauSac> list = new ArrayList<>();
        try(Session session = HibernateUtil.getFACTORY().openSession()){
            // Mở một phiên làm việc với cơ sở dữ liệu
            // Tạo truy vấn để lấy tất cả các đối tượng MauSac và sắp xếp theo mã màu giảm dần
            Query query = session.createQuery("FROM MauSac ORDER BY maMau DESC");
            // Lấy kết quả của truy vấn và gán cho danh sách
            list = query.getResultList();
        }catch (Exception e){
            // Bắt và in ra màn hình nếu có bất kỳ ngoại lệ nào xảy ra
            e.printStackTrace();
        }
        // Trả về danh sách chứa tất cả các đối tượng MauSac
        return list;
    }

    public MauSac getMauSacByMa(String ma){
        // Khởi tạo một đối tượng MauSac với giá trị mặc định là null
        MauSac ms = null;
        try(Session session = HibernateUtil.getFACTORY().openSession()){
            // Kết nối cơ sở dữ liệu
            // Truy vấn để lấy đối tượng MauSac dựa trên mã màu
            Query query = session.createQuery("from MauSac where maMau =: maMau");
            // Tham số cho truy vấn
            query.setParameter("maMau",ma);
            // Lấy giá trị vừa truy vấn và gán cho đối tượng MauSac
            ms = (MauSac) query.uniqueResult();
        }catch (Exception e){
            // Bắt và in ra màn hình nếu có bất kỳ ngoại lệ nào xảy ra
            e.printStackTrace();
        }
        // Trả về đối tượng MauSac hoặc null nếu không tìm thấy
        return ms;
    }

    // Hàm này để thêm mới
    public boolean add(MauSac mauSac){
        Transaction transaction = null;
        try(Session session = HibernateUtil.getFACTORY().openSession()){
            // Ket noi với cơ sở dữ liệu
            transaction = session.beginTransaction();
            // Thêm đối tượng MauSac vào db
            session.persist(mauSac);
            // Commit giao dịch
            transaction.commit();
            // Trả về true nếu thêm mới thành công
            return true;
        }catch (Exception e){
            e.printStackTrace();
        }
        // Trả về false nếu thêm mới thất bại
        return false;
    }

    // Hàm này dùng để xóa
    public boolean delete(MauSac mauSac){
        Transaction transaction = null;
        try(Session session = HibernateUtil.getFACTORY().openSession()){
            // Kết nối với db
            transaction = session.beginTransaction();
            // Xóa đối tượng MauSac db
            session.delete(mauSac);
            // Commit giao dịch
            transaction.commit();
            // Trả về true nếu xóa thành công
            return true;
        }catch (Exception e){
            e.printStackTrace();
        }
        // Trả về false nếu xóa thất bại
        return false;
    }


    // Hàm này dùng để cập nhật
    public boolean update(MauSac mauSac,String ma){
        Transaction transaction = null;
        try(Session session = HibernateUtil.getFACTORY().openSession()){
            transaction = session.beginTransaction();
            Query query = session.createQuery("update MauSac set " +
                    "tenMau =: tenMau," +
                    "trangThai =: trangThai, " +
                    "ngaySua =: ngaySua " +
                    "where maMau =: maMau"
            );
            query.setParameter("tenMau", mauSac.getTenMau());
            query.setParameter("trangThai", mauSac.getTrangThai()); // Thêm các tham số còn thiếu
            query.setParameter("ngaySua", mauSac.getNgaySua()); // Thêm các tham số còn thiếu
            query.setParameter("maMau", ma);
            query.executeUpdate();
            transaction.commit();
            return true; // Trả về true nếu cập nhật thành công
        } catch (Exception e){
            e.printStackTrace();
        }
        return false;
    }

    // Ham dung de tim kiem
    public List<MauSac> searchMauSac(String tenMau) {
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query<MauSac> query = session.createQuery("SELECT m FROM MauSac m WHERE m.tenMau LIKE :tenMau", MauSac.class);
            query.setParameter("tenMau", "%" + tenMau + "%");
            return query.list();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

}
