package reponse.admin;

import jakarta.persistence.ParameterMode;
import jakarta.persistence.StoredProcedureQuery;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.*;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.procedure.ProcedureCall;
import org.hibernate.query.Query;
import util.HibernateUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class BanHangRepository {

    // Hàm này để lấy ra danh sách sản phẩm
    public List<ChiTietSanPham> getAllCTSP() {
        List<ChiTietSanPham> listCTSP = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query<ChiTietSanPham> query = session.createQuery("SELECT ctsp FROM ChiTietSanPham ctsp WHERE ctsp.trangThai =: trangThai", ChiTietSanPham.class);
            query.setParameter("trangThai", "Hoạt động");
            listCTSP = query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listCTSP;
    }


    // Hàm này dùng để lấy ra khách hàng
    public KhachHang getKhachHangById(Integer id) {
        KhachHang khachHang = null;
        try {
            Session session = HibernateUtil.getFACTORY().openSession();
            String hql = "SELECT a FROM KhachHang a WHERE a.id = :id";
            Query<KhachHang> query = session.createQuery(hql);
            query.setParameter("id", id);
            khachHang = (KhachHang) query.getSingleResult();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return khachHang;
    }

    // Hàm này dùng để tạo hóa đơn
    public HoaDon saveOrUpdateHD(HoaDon hoaDon) {
        try {
            Session session = HibernateUtil.getFACTORY().openSession();
            Transaction trans = session.beginTransaction();
            session.saveOrUpdate(hoaDon);
            trans.commit();
            session.close();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return hoaDon;
    }


//    public HoaDon getKhachHangBySdt(String sdt){
//        HoaDon hoaDon = null;
//        try (Session session = HibernateUtil.getFACTORY().openSession()) {
//            Query<HoaDon> query = session.createQuery("SELECT kh FROM HoaDon kh WHERE kh.khachHang.sdt LIKE :sdt", HoaDon.class);
//            query.setParameter("sdt", "%" + sdt + "%");
//            hoaDon = query.uniqueResult();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return hoaDon;
//    }

    // Hàm này để lấy ra khách hàng khi tìm kiếm bằng sdt
    public KhachHang searchKhachHangBySdt(String sdt) {
        KhachHang list = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query<KhachHang> query = session.createQuery("SELECT kh FROM KhachHang kh WHERE kh.sdt LIKE :sdt", KhachHang.class);
            query.setParameter("sdt", "%" + sdt + "%");
            list = query.uniqueResult();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }


    public KhachHang getIdByName(String hoTen) {
        KhachHang khachHang = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query<KhachHang> query = session.createQuery("SELECT kh FROM KhachHang kh WHERE kh.hoTen LIKE :hoTen", KhachHang.class);
            query.setParameter("hoTen", hoTen.trim());
            khachHang = query.uniqueResult();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return khachHang;
    }

//    public static void main(String[] args) {
//        BanHangRepository banHangRepository = new BanHangRepository();
//        KhachHang khachHang = new KhachHang();
//        khachHang.setHoTen("John Doe");
//        KhachHang result = banHangRepository.getIdByName("John");
//        for (KhachHang kh: banHangRepository.getIdByName(hoten)){
//
//        }
//    }

    //hàm này có chức năng thêm sản phẩm vào giỏ
    public int insertHoaDonCTPROC(HoaDonChiTiet hoaDonChiTiet) {
        Session session = null;
        Transaction transaction = null;
        try {
            session = HibernateUtil.getFACTORY().openSession();
            transaction = session.beginTransaction();

            StoredProcedureQuery query = session.createStoredProcedureQuery("ThemSanPhamVaoHoaDonChiTiet");
            query.registerStoredProcedureParameter(1, Integer.class, ParameterMode.IN);
            query.registerStoredProcedureParameter(2, Integer.class, ParameterMode.IN);
            query.registerStoredProcedureParameter(3, Integer.class, ParameterMode.IN);

            query.setParameter(1, hoaDonChiTiet.getHoaDon().getIdHoaDon());
            query.setParameter(2, hoaDonChiTiet.getChiTietSanPham().getId());
            query.setParameter(3, hoaDonChiTiet.getSoLuongMua());

            query.execute();
            transaction.commit();
            return 1;
        } catch (Exception e) {
            e.printStackTrace();
            session.close();
        }
        return 0;
    }

    public int insertHoaDonCT(HoaDonChiTiet hoaDonChiTiet) {
        Session session = null;
        Transaction transaction = null;
        try {
            session = HibernateUtil.getFACTORY().openSession();
            transaction = session.beginTransaction();
            session.save(hoaDonChiTiet);
            transaction.commit();
            return 1;
        } catch (Exception e) {
            e.printStackTrace();
            session.close();
        }
        return 0;
    }

    // Ham nay dung de lay ra id cua ctsp
    public Integer getIdChiTietSanPham(Integer id) {
        Integer IdCTSanPham = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query query = session.createQuery("FROM ChiTietSanPham WHERE id = :id");
            query.setParameter("id", IdCTSanPham);
            IdCTSanPham = (Integer) query.getSingleResult();
        }
        return IdCTSanPham;
    }

    // Hàm này lấy ra id của hóa đơn
    public Integer getIdHoaDon(Integer id) {
        Integer IdHoaDon = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query query = session.createQuery("FROM HoaDon WHERE idHoaDon = :id");
            query.setParameter("id", IdHoaDon);
            IdHoaDon = (Integer) query.getSingleResult();
        }
        return IdHoaDon;
    }

    // Hàm này hoá đơn chi tiết bang id hoa don
    public List<HoaDonChiTiet> getHoaDonChiTietByHoaDonId(Integer hoaDonId) {
        List<HoaDonChiTiet> list = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            String hql = "SELECT hdct FROM HoaDonChiTiet hdct WHERE hdct.hoaDon.id = :hoaDonId AND hdct.trangThai = :trangThai";
            Query<HoaDonChiTiet> query = session.createQuery(hql, HoaDonChiTiet.class);
            query.setParameter("hoaDonId", hoaDonId);
            query.setParameter("trangThai", "Chờ thanh toán");
            list = query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Hàm này lấy ra chi tiết sản phẩm bằng id sản phẩm
    public List<HoaDonChiTiet> getCTSPByIDCTSP(Integer idCTSP) {
        List<HoaDonChiTiet> list = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            String hql = "SELECT hdct FROM HoaDonChiTiet hdct WHERE hdct.chiTietSanPham.id = :idCTSP";
            Query<HoaDonChiTiet> query = session.createQuery(hql, HoaDonChiTiet.class);
            query.setParameter("idCTSP", idCTSP);
            list = query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Hàm này dùng để lấy ra 1 hóa đơn bằng id
    public HoaDon getHoaDonById(Integer id) {
        HoaDonRepon hdrp = new HoaDonRepon();
        HoaDon hoaDon = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query<HoaDon> query = session.createQuery("FROM HoaDon P JOIN FETCH P.khachHang WHERE P.idHoaDon = :id");
            query.setParameter("id", id);
            hoaDon = (HoaDon) query.uniqueResult(); // Sử dụng uniqueResult() nếu bạn chắc chắn rằng mã sản phẩm là duy nhất
        } catch (Exception e) {
            e.printStackTrace();
        }
        hoaDon.setTongTien(hdrp.getTongTienByIdHoaDona(id));
        return hoaDon;

    }

    // Hàm này dùng để thêm sản phẩm vào hóa đơn ct
    public void themSanPhamVaoHoaDonChiTiet(int idHD, int idCTSP, int soLuong) {
        System.out.println("bat dau them");
        Session session = HibernateUtil.getFACTORY().openSession();
        try {
            session.beginTransaction();
            System.out.println("goi proc");
            StoredProcedureQuery query = session.createStoredProcedureQuery("ThemSanPhamVaoHoaDonChiTiet");
            System.out.println("set param");
            query.registerStoredProcedureParameter("IDHD", Integer.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("IDCTSP", Integer.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("SoLuong", Integer.class, ParameterMode.IN);

            query.setParameter("IDHD", idHD);
            query.setParameter("IDCTSP", idCTSP);
            query.setParameter("SoLuong", soLuong);

            query.execute();
            System.out.println("Dong 208");
            session.getTransaction().commit();
            System.out.println("Dong 210 : ");
        } catch (Exception e) {
            e.printStackTrace();
            if (session.getTransaction() != null) {
                session.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {

            session.close();
        }
    }

    // Hàm này dùng để xóa sản phẩm khỏi giỏ hàng
    public void xoaSanPhamKhoiHoaDonChiTiet(int idHDCT, int idCTSP) {
        Session session = HibernateUtil.getFACTORY().openSession();
        try {
            session.beginTransaction();
            StoredProcedureQuery query = session.createStoredProcedureQuery("XoaSanPhamKhoiGioHang");
            query.registerStoredProcedureParameter("IDHDCT", Integer.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("IDCTSP", Integer.class, ParameterMode.IN);

            query.setParameter("IDHDCT", idHDCT);
            query.setParameter("IDCTSP", idCTSP);

            query.execute();
            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            if (session.getTransaction() != null) {
                session.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {

            session.close();
        }
    }

    // Hàm này dùng để thanh toán hóa đơn
    public void thanhToanHoaDon(int idHD, int idKH) {
        Session session = HibernateUtil.getFACTORY().openSession();
        try {
            session.beginTransaction();
            StoredProcedureQuery query = session.createStoredProcedureQuery("THANHTOANHOADON");
            query.registerStoredProcedureParameter("idHD", Integer.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("idKH", Integer.class, ParameterMode.IN);

            query.setParameter("idHD", idHD);
            query.setParameter("idKH", idKH);

            query.execute();
            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            if (session.getTransaction() != null) {
                session.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {

            session.close();
        }
    }

    // Hàm này dùng để cập nhật số lượng sản phẩm trong giỏ hàng
    public void capNhatSanPhamTrongGioHang(int idCTSP, int idHDCT, int soLuongThayDoi, int soLuongSPtrongGio) {
        Session session = HibernateUtil.getFACTORY().openSession();
        try {
            session.beginTransaction();
            StoredProcedureQuery query = session.createStoredProcedureQuery("CapNhatSanPhamTrongGioHang");
            query.registerStoredProcedureParameter("IDCTSP", Integer.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("IDHDCT", Integer.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("SOLUONGSPTHAYDOI", Integer.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("SOLUONGSPTRONGGIO", Integer.class, ParameterMode.IN);

            query.setParameter("IDCTSP", idCTSP);
            query.setParameter("IDHDCT", idHDCT);
            query.setParameter("SOLUONGSPTHAYDOI", soLuongThayDoi);
            query.setParameter("SOLUONGSPTRONGGIO", soLuongSPtrongGio);
            query.execute();
            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            if (session.getTransaction() != null) {
                session.getTransaction().rollback();
            }
        } finally {
            session.close();
        }
    }

    public int getSoLuongTonByIDCTSP(Integer idCTSP) {
        Integer soLuong = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query<ChiTietSanPham> query = session.createQuery("FROM ChiTietSanPham WHERE id = :id");
            query.setParameter("id", idCTSP);
            soLuong = query.getResultList().get(0).getSoLuongTon();
        }
        return soLuong;
    }

    public int getSoLuongTrongGioHangByIdCTSP(Integer idCTSP) {
        Integer soLuong = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query<HoaDonChiTiet> query = session.createQuery("select hdct FROM HoaDonChiTiet hdct WHERE hdct.chiTietSanPham.id = :idCTSP", HoaDonChiTiet.class);
            query.setParameter("idCTSP", idCTSP);
            soLuong = query.getResultList().get(0).getSoLuongMua();
        }
        return soLuong;
    }
//    private void updatesp(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
//        if (request.getParameter("idCTSP") != null && request.getParameter("idHDCT") != null && request.getParameter("soLuongThayDoi") != null && !request.getParameter("soLuongThayDoi").isEmpty()) {
////            int soLuongTon = reponBH.getSoLuongTonByIDCTSP(Integer.valueOf(request.getParameter("idCTSP")));
////            int idHoaDon = Integer.parseInt(request.getParameter("idHoaDon"));
//            int idCTSP = Integer.parseInt(request.getParameter("idCTSP"));
//            int idHDCT = Integer.parseInt(request.getParameter("idHDCT"));
//            int soLuongThayDoi = 0;
//            try {
//                soLuongThayDoi = Integer.parseInt(request.getParameter("soLuongThayDoi"));
//            } catch (Exception e) {
//                alert("Số lượng phải là số!!", request);
//                hienThi(request, response);
//                return;
//            }
//
//            int soLuongTrongGio = Integer.parseInt(request.getParameter("soLuongTrongGio"));
//            if (checkUpdateGioHang(request, response)) {
//                reponBH.capNhatSanPhamTrongGioHang(idCTSP, idHDCT, soLuongThayDoi, soLuongTrongGio);
//                saveForm(request, response);
//            }
//        } else {
//            saveForm(request, response);
//
//        }
//
//    }

}
