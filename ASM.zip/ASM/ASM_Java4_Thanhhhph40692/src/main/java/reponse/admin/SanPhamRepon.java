package reponse.admin;

import model.DanhMuc;
import model.SanPham;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import util.HibernateUtil;

import java.util.ArrayList;
import java.util.List;

public class SanPhamRepon {

    public List<SanPham> getAll() {
        List<SanPham> danhSachSanPham = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query<SanPham> query = session.createQuery("select sp FROM SanPham sp", SanPham.class);
            danhSachSanPham = query.getResultList();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return danhSachSanPham;
    }

    // Hàm này dùng để lấy ra sản phẩm bằng mã để làm detail
    public SanPham getSanPhamByMa(String ma){
        SanPham sanPham = null;
        try(Session session = HibernateUtil.getFACTORY().openSession()){
            Query query = session.createQuery("FROM SanPham WHERE maSanPham = :maSanPham");
            query.setParameter("maSanPham", ma);
            sanPham = (SanPham) query.uniqueResult(); // Sử dụng uniqueResult() nếu bạn chắc chắn rằng mã sản phẩm là duy nhất
        } catch (Exception e) {
            e.printStackTrace();
        }
        return sanPham;
    }

    public Integer getMaDanhMuc(Integer id){
        Integer idDanhMuc = null;
        try(Session session = HibernateUtil.getFACTORY().openSession()){
            Query query = session.createQuery("SELECT DanhMuc.maDanhMuc FROM DanhMuc WHERE id = :id");
            query.setParameter("id", idDanhMuc);
            idDanhMuc = (Integer) query.getSingleResult();
        }
        return idDanhMuc;
    }

    public boolean add(SanPham sanPham) {
        Transaction transaction = null;
        try(Session session = HibernateUtil.getFACTORY().openSession()) {
            transaction = session.beginTransaction();
            session.persist(sanPham);
            transaction.commit();
            return true;
        }catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Hàm này dùng để cập nhật
    public boolean update(SanPham sanPham, String ma) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            transaction = session.beginTransaction();

            Query query = session.createQuery("update SanPham set " +
                    "tenSanPham = :tenSanPham, " +
                    "danhMuc = :danhMuc, " +
                    "trangThai = :trangThai, " +
                    "ngaySua = :ngaySua " +
                    "where maSanPham = :maSanPham"
            );

            query.setParameter("tenSanPham", sanPham.getTenSanPham());
            query.setParameter("danhMuc", sanPham.getDanhMuc());
            query.setParameter("trangThai", sanPham.getTrangThai());
            query.setParameter("ngaySua", sanPham.getNgaySua());
            query.setParameter("maSanPham", ma);

            int result = query.executeUpdate();

            transaction.commit();
            return result > 0; // Trả về true nếu có ít nhất một hàng được cập nhật
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean delete(SanPham sanPham){
        Transaction transaction = null;
        try(Session session = HibernateUtil.getFACTORY().openSession()){
            transaction = session.beginTransaction();
            session.delete(sanPham);
            transaction.commit();
            return true;
        }catch (Exception e){
            e.printStackTrace();
        }
        return false;
    }

    // Hàm này dùng để tìm kiếm size theo tên và mã
    public List<SanPham> searchSanPhambyNamebyMa(String name, String ma) {
        List<SanPham> list = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query<SanPham> query = session.createQuery("SELECT hd FROM SanPham hd WHERE hd.maSanPham LIKE :ma OR hd.tenSanPham LIKE :name", SanPham.class);
            query.setParameter("name", "%" + name + "%");
            query.setParameter("ma", "%" + ma + "%");
            list = query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
