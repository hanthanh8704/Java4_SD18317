package reponse.admin;



import model.HoaDon;
import model.HoaDonChiTiet;
import org.hibernate.Session;
import org.hibernate.query.Query;
import util.HibernateUtil;

import java.util.ArrayList;
import java.util.List;

public class HoaDonChiTietRepon {
    public List<HoaDonChiTiet> getAll(){
        List<HoaDonChiTiet> listHDCT = new ArrayList<>();
        try(Session session = HibernateUtil.getFACTORY().openSession()){
            Query<HoaDonChiTiet> query = session.createQuery("FROM HoaDonChiTiet P JOIN FETCH P.hoaDon JOIN FETCH P.chiTietSanPham JOIN FETCH P.chiTietSanPham.sanPham");
            listHDCT = query.getResultList();
        }catch (Exception e){
            e.printStackTrace();
        }
        return listHDCT;
    }
    public HoaDonChiTiet getHoaDonChiTietById(Integer id){
        HoaDonChiTiet hoaDonChiTiet = null;
        try(Session session = HibernateUtil.getFACTORY().openSession()){
            Query query = session.createQuery("FROM HoaDonChiTiet where id =: id");
            query.setParameter("id",id);
            hoaDonChiTiet = (HoaDonChiTiet) query.uniqueResult();
        }
        return hoaDonChiTiet;
    }

}
