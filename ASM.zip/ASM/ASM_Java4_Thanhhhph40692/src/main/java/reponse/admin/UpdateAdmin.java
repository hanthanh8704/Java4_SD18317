package reponse.admin;

import model.SanPham;
import org.hibernate.Session;
import org.hibernate.Transaction;
import util.HibernateUtil;

public class UpdateAdmin{
    public void update(SanPham sanPham, Integer id){
        Transaction transaction = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()){
            transaction = session.beginTransaction();
            SanPham sp = session.get(SanPham.class,id);
            if(sp != null){
                sp.setId(sanPham.getId());
                sp.setMaSanPham(sanPham.getMaSanPham());
                sp.setTenSanPham(sanPham.getTenSanPham());
                sp.setDanhMuc(sanPham.getDanhMuc());
                sp.setTrangThai(sanPham.getTrangThai());
                sp.setNgaySua(sanPham.getNgaySua());
                session.update(sp);
                transaction.commit();
            };
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void delete(SanPham sanPham, Integer id){
        Transaction transaction = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()){
            transaction = session.beginTransaction();
            SanPham sp = session.get(SanPham.class,id);
            if(sp != null){
                session.delete(sp);
                transaction.commit();
            };
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
