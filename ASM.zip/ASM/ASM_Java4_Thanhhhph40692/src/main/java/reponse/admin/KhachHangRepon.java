package reponse.admin;

import model.KhachHang;
import model.Size;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import util.HibernateUtil;

import java.util.ArrayList;
import java.util.List;

public class KhachHangRepon {
    // Hàm hiển thị
    public List<KhachHang> getAll(){
        List<KhachHang> list = new ArrayList<>();
        try(Session session = HibernateUtil.getFACTORY().openSession()){
            Query query = session.createQuery("FROM KhachHang ORDER BY id asc ");
            list = query.getResultList();
        }catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }

    // Hàm này để trả về đối tuong
    public KhachHang getKhachHangById(Integer id){
        KhachHang khachHang = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()){
            Query query = session.createQuery("FROM KhachHang where id =: id");
            query.setParameter("id",id);
            khachHang = (KhachHang) query.uniqueResult();
        }catch (Exception e){
            e.printStackTrace();
        }
        return khachHang;
    }

    // Hàm thêm
    public boolean add(KhachHang khachHang){
        Transaction transaction = null;
        try(Session session = HibernateUtil.getFACTORY().openSession()){
            transaction = session.beginTransaction();
            session.persist(khachHang);
            transaction.commit();
            return true;
        }catch (Exception e){
            e.printStackTrace();
        }
        return false;
    }

    // Hàm xóa
    public boolean delete(KhachHang khachHang){
        Transaction transaction = null;
        try(Session session = HibernateUtil.getFACTORY().openSession()){
            transaction = session.beginTransaction();
            session.delete(khachHang);
            transaction.commit();
            return true;
        }catch (Exception e){
            e.printStackTrace();
        }
        return false;
    }

    // Hàm cập nhật
    public boolean update(KhachHang khachHang, Integer id){
        Transaction transaction = null;
        try(Session session = HibernateUtil.getFACTORY().openSession()){
            transaction = session.beginTransaction();
            Query query = session.createQuery("UPDATE KhachHang SET" +
                    " hoTen =: hoTen," +
                    " diaChi =: diaChi," +
                    " sdt =: sdt," +
                    " trangThai =: trangThai," +
                    " ngaySua =: ngaySua" +
                    " WHERE id =: id"
            );
            query.setParameter("hoTen",khachHang.getHoTen());
            query.setParameter("diaChi",khachHang.getDiaChi());
            query.setParameter("sdt",khachHang.getSdt());
            query.setParameter("trangThai",khachHang.getTrangThai());
            query.setParameter("ngaySua",khachHang.getNgaySua());
            query.setParameter("id", id);
            query.executeUpdate();
            transaction.commit();;
            return true;
        }catch (Exception e){
            e.printStackTrace();
        }
        return false;
    }

    // Hàm này dùng để tìm kiếm khách hàng theo tên và địa chỉ , sdt
    public List<KhachHang> searchSizebyNamebySDTbyDiaChi(String name, String sdt, String diachi) {
        List<KhachHang> list = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query<KhachHang> query = session.createQuery("SELECT hd FROM KhachHang hd WHERE hd.hoTen LIKE :name OR hd.sdt LIKE :sdt OR hd.diaChi LIKE :diachi", KhachHang.class);
            query.setParameter("name", "%" + name + "%");
            query.setParameter("sdt", "%" + sdt + "%");
            query.setParameter("diachi", "%" + diachi + "%");
            list = query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
