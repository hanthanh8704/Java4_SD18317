package reponse.admin;

import model.HoaDon;
import model.MauSac;
import model.Size;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import util.HibernateUtil;

import java.util.ArrayList;
import java.util.List;

public class SizeRepon {
    // Hàm này dùng để hiển thị dữ liệu các bảng lên table
    public List<Size> getAll() {
        List<Size> list = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query query = session.createQuery("FROM Size ORDER BY maSize ASC");
            list = query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Hàm này trả về đối tương Size
    public Size getKichCoByMa(String ma) {
        // Khởi tạo một đối tượng MauSac với giá trị mặc định là null
        Size size = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            // Kết nối cơ sở dữ liệu
            // Truy vấn để lấy đối tượng MauSac dựa trên mã màu
            Query query = session.createQuery("from Size where maSize =: maSize");
            // Tham số cho truy vấn
            query.setParameter("maSize", ma);
            // Lấy giá trị vừa truy vấn và gán cho đối tượng MauSac
            size = (Size) query.uniqueResult();
        } catch (Exception e) {
            // Bắt và in ra màn hình nếu có bất kỳ ngoại lệ nào xảy ra
            e.printStackTrace();
        }
        // Trả về đối tượng MauSac hoặc null nếu không tìm thấy
        return size;
    }

    // Hàm này dùng để thêm mới
    public boolean add(Size size) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            transaction = session.beginTransaction();
            session.persist(size);
            transaction.commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Hàm này dùng để xóa
    public boolean delete(Size size) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            transaction = session.beginTransaction();
            session.delete(size);
            transaction.commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Hàm này dùng để cập nhật
    public boolean update(Size size, String ma) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            transaction = session.beginTransaction();
            Query query = session.createQuery("update Size set " +
                    "tenSize =: tenSize," +
                    "trangThai =: trangThai, " +
                    "ngaySua =: ngaySua " +
                    "where maSize =: maSize"
            );
            query.setParameter("tenSize", size.getTenSize());
            query.setParameter("trangThai", size.getTrangThai()); // Thêm các tham số còn thiếu
            query.setParameter("ngaySua", size.getNgaySua()); // Thêm các tham số còn thiếu
            query.setParameter("maSize", ma);
            query.executeUpdate();
            transaction.commit();
            return true; // Trả về true nếu cập nhật thành công
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Hàm này dùng để tìm kiếm size theo tên và mã
    public List<Size> searchSizebyNamebyMa(String name, String ma) {
        List<Size> list = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query<Size> query = session.createQuery("SELECT hd FROM Size hd WHERE hd.maSize LIKE :ma OR hd.tenSize LIKE :name", Size.class);
            query.setParameter("name", "%" + name + "%");
            query.setParameter("ma", "%" + ma + "%");
            list = query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
