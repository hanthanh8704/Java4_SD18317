package reponse.admin;

import model.DanhMuc;
import model.MauSac;
import model.Size;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import util.HibernateUtil;

import java.util.ArrayList;
import java.util.List;

public class DanhMucRepon {

    public List<DanhMuc> getAll() {
        // Tạo 1 danh sách để lưu trữ kết quả
        List<DanhMuc> list = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            // try vấn sql
            Query query = session.createQuery("FROM DanhMuc ORDER BY maDanhMuc ASC ");
            // lấy kq vừa truy vấn được cho danh sách
            list = query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Hàm để lấy 1 đối tượng danh mục qua mã
    public DanhMuc getDanhMucByMa(String ma) {
        // khởi tạo
        DanhMuc dm = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query query = session.createQuery("FROM DanhMuc WHERE maDanhMuc =: maDanhMuc");
            query.setParameter("maDanhMuc", ma);
            dm = (DanhMuc) query.uniqueResult();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dm;
    }

    // Hàm này để thêm mới
    public boolean add(DanhMuc danhMuc) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            transaction = session.beginTransaction();
            session.persist(danhMuc);
            transaction.commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Hàm dùng để xóa
    public boolean delete(DanhMuc danhMuc) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            transaction = session.beginTransaction();
            session.delete(danhMuc);
            transaction.commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Hàm dùng để cập nhật
    public boolean update(DanhMuc danhMuc, String ma) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            transaction = session.beginTransaction();
            Query query = session.createQuery("update DanhMuc set " +
                    "tenDanhMuc =: tenDanhMuc," +
                    "trangThai =: trangThai, " +
                    "ngaySua =: ngaySua " +
                    "where maDanhMuc =: maDanhMuc"
            );
            query.setParameter("tenDanhMuc", danhMuc.getTenDanhMuc());
            query.setParameter("trangThai", danhMuc.getTrangThai()); // Thêm các tham số còn thiếu
            query.setParameter("ngaySua", danhMuc.getNgaySua()); // Thêm các tham số còn thiếu
            query.setParameter("maDanhMuc", ma);
            query.executeUpdate();
            transaction.commit();
            return true; // Trả về true nếu cập nhật thành công
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Hàm này dùng để tìm kiếm danh mục theo tên và mã
    public List<DanhMuc> searchDanhMucbyNamebyMa(String name, String ma) {
        List<DanhMuc> list = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query<DanhMuc> query = session.createQuery("SELECT hd FROM DanhMuc hd WHERE hd.maDanhMuc LIKE :ma OR hd.tenDanhMuc LIKE :name", DanhMuc.class);
            query.setParameter("name", "%" + name + "%");
            query.setParameter("ma", "%" + ma + "%");
            list = query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
