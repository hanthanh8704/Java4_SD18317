package reponse.admin;

import model.HoaDon;
import model.HoaDonChiTiet;
import model.HoaDonPage;
import model.SanPham;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import util.HibernateUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class HoaDonRepon {
    public List<HoaDon> getAllHD() {
        List<HoaDon> listHD = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query<HoaDon> query = session.createQuery("SELECT hd FROM HoaDon hd JOIN FETCH hd.khachHang", HoaDon.class);
//            query.setParameter("trangThai", "Đã thanh toán");
            listHD = query.getResultList();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return listHD;
    }

    // Hàm lấy ra danh sách hóa đơn
    public List<HoaDon> getListDTT() {
        List<HoaDon> listHD = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            String hql = "FROM Post P  JOIN FETCH P.user  JOIN FETCH P.category ";
            Query<HoaDon> query = session.createQuery("SELECT H FROM HoaDon H JOIN FETCH H.khachHang WHERE H.trangThai =: trangThai", HoaDon.class);
            query.setParameter("trangThai", "Đã thanh toán");
            listHD = query.getResultList();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return listHD;
    }

    public List<HoaDon> getListCTTT() {
        List<HoaDon> listHD = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            String hql = "FROM Post P  JOIN FETCH P.user  JOIN FETCH P.category ";
            Query<HoaDon> query = session.createQuery("SELECT H FROM HoaDon H JOIN FETCH H.khachHang WHERE H.trangThai =: trangThai", HoaDon.class);
            query.setParameter("trangThai", "Chờ thanh toán");
            listHD = query.getResultList();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return listHD;
    }

    // Hàm lấy tổng tiền từ hóa đơn chi tiết
    public BigDecimal getTongTienByIdHoaDona(Integer id) {
        List<HoaDonChiTiet> listHDCT = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query<HoaDonChiTiet> query = session.createQuery("FROM HoaDonChiTiet WHERE hoaDon.idHoaDon =: id");
            query.setParameter("id", id);
            listHDCT = query.getResultList();
        }
        BigDecimal tongTien = BigDecimal.ZERO;
        for (HoaDonChiTiet hd : listHDCT) {
            tongTien = tongTien.add(hd.getTongTien());
        }
        return tongTien;
    }

    public List<HoaDonChiTiet> getTongTienByIdHoaDon(Integer id) {
        List<HoaDonChiTiet> listHDCT = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query<HoaDonChiTiet> query = session.createQuery("FROM HoaDonChiTiet WHERE hoaDon.idHoaDon =: id");
            query.setParameter("id", id);
            listHDCT = query.getResultList();
        }
        return listHDCT;
    }

    // Hàm này dùng để lấy ra hdct bằng id hóa đơn
    public List<HoaDonChiTiet> getHDCTByIDHD(Integer id) {
        List<HoaDonChiTiet> listHDCT = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query<HoaDonChiTiet> query = session.createQuery("FROM HoaDonChiTiet WHERE hoaDon.idHoaDon =: id");
            query.setParameter("id", id);
            listHDCT = query.getResultList();
        }

        return listHDCT;
    }

    public HoaDon getHoaDonById(Integer id) {
        HoaDon hoaDon = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query query = session.createQuery("FROM HoaDon where id =: id");
            query.setParameter("id", id);
            hoaDon = (HoaDon) query.uniqueResult();
        }
        return hoaDon;
    }

    public HoaDonChiTiet getHoaDonChiTietById(Integer id) {
        HoaDonChiTiet hoaDonChiTiet = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query query = session.createQuery("FROM HoaDonChiTiet where id =: id");
            query.setParameter("id", id);
            hoaDonChiTiet = (HoaDonChiTiet) query.uniqueResult();
        }
        return hoaDonChiTiet;
    }

    public List<HoaDonChiTiet> listHDCTByIDHoaDon(Integer idHoaDon) {
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query query = session.createQuery("FROM HoaDonChiTiet WHERE hoaDon.idHoaDon =: idHoaDon");
            query.setParameter("idHoaDon", idHoaDon);
            return query.getResultList();
        }
    }

//    public List<HoaDon> getAllTongTien() {
//        List<HoaDon> hoaDonList = new ArrayList<>();
//        try (Session session = HibernateUtil.getFACTORY().openSession()) {
//            String hql = "SELECT (SELECT SUM(soLuongMua * giaBan) FROM HoaDonChiTiet WHERE HoaDonChiTiet.hoaDon.idHoaDon = hoaDon.id) AS TongTien FROM HoaDon JOIN FETCH KhachHang";
//            Query<HoaDon> query = session.createQuery(hql, HoaDon.class);
//            hoaDonList = query.list();
//        } catch (Exception ex) {
//            ex.printStackTrace();
//        }
//        return hoaDonList;
//    }

    // Hàm này để tìm kiếm hóa đơn theo id
    public List<HoaDon> searchHDbyID(Integer id) {
        List<HoaDon> list = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query<HoaDon> query = session.createQuery("SELECT hd FROM HoaDon hd WHERE hd.idHoaDon =: id", HoaDon.class);
            list = query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }


    // Hàm này để tìm kiếm hóa đơn theo các trường trong hóa đn
    public List<HoaDon> searchHDbyNamebyDiaChibySDT(String name, String sdt, String diaChi) {
        List<HoaDon> list = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query<HoaDon> query = session.createQuery("SELECT hd FROM HoaDon hd WHERE hd.khachHang.hoTen LIKE :name OR hd.diaChi LIKE :diaChi OR hd.soDienThoai LIKE :sdt", HoaDon.class);
            query.setParameter("name", "%" + name + "%");
            query.setParameter("sdt", "%" + sdt + "%");
            query.setParameter("diaChi", "%" + diaChi + "%");
            list = query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }


    // Hàm này dùng để tìm kiếm số lượng hóa đơn
    public int countHoaDon(int idHoaDon) {
        // total : bắt đầu từ 0
        int total = 0;
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            String queryString;
            // Xây dựng câu truy vấn dựa trên giá trị của idHoaDon
            if (idHoaDon == 0) {
                // Truy vấn đếm tổng số lượng hóa đơn
                queryString = "SELECT COUNT(*) FROM HoaDon";
            } else {
                // Truy vấn đếm tổng số lượng hóa đơn có idHoaDon cụ thể
                queryString = "SELECT COUNT(*) FROM HoaDon WHERE idHoaDon = :idHoaDon";
            }
            // Tạo đối tượng truy vấn
            Query<Long> query = session.createQuery(queryString, Long.class);
            // Thiết lập tham số idHoaDon nếu idHoaDon khác 0
            if (idHoaDon != 0) {
                query.setParameter("idHoaDon", idHoaDon);
            }
            // Thực hiện truy vấn và lấy kết quả
            total = query.uniqueResult().intValue();
        } catch (Exception e) {
            e.printStackTrace();
        }
        // Trả về tổng số lượng hóa đơn
        return total;
    }

    //  Hàm này dùng để phân trang theo danh mục
    // pageno là trang hiện tại
    // pagesize là kích thước trang
    public HoaDonPage paging(int idHoaDon, int pageno, int pagesize) {
        HoaDonPage data = null;
        List<HoaDon> hoadon = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            String queryString;
            // Xây dựng câu truy vấn dựa trên giá trị của cateid, pageno và pagesize
            if (idHoaDon == 0) {
                // Truy vấn lấy tất cả các hoa và thực hiện phân trang
                queryString = "select hd FROM HoaDon hd ORDER BY hd.ngayTao ";
            } else {
                // Truy vấn lấy các hoa thuộc categoryid và thực hiện phân trang
                queryString = "select hd FROM HoaDon hd WHERE hd.idHoaDon = :idHoaDon ORDER BY hd.ngayTao";
            }
            // Tạo đối tượng truy vấn
            Query<HoaDon> query = session.createQuery(queryString, HoaDon.class);
            // Thiết lập tham số cateid nếu cateid khác 0
            if (idHoaDon != 0) {
                query.setParameter("idHoaDon", idHoaDon);
            }
            // Thiết lập vị trí bắt đầu của kết quả trả về dựa trên trang và kích thước trang
            int startRow = (pageno - 1) * pagesize;
            query.setFirstResult(startRow);
            // Thiết lập số lượng kết quả trả về dựa trên kích thước trang
            query.setMaxResults(pagesize);
            // Thực hiện truy vấn và lấy danh sách kết quả
            hoadon = query.list();
            // Tính tổng số trang dựa trên số lượng bản ghi và kích thước trang
            int totalRows = countHoaDon(idHoaDon);
            int totalPages = (totalRows % pagesize == 0) ? totalRows / pagesize : (totalRows / pagesize) + 1;
            // Tạo đối tượng FlowerPage với các thông tin về dữ liệu phân trang
            data = new HoaDonPage(hoadon, totalPages, pagesize, pageno);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // Trả về đối tượng FlowerPage
        return data;
    }

}
