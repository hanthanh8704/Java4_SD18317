package reponse.admin;

import model.ChiTietSanPham;
import model.SanPham;
import model.Size;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import util.HibernateUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class ChiTietSanPhamRepon {
    public List<ChiTietSanPham> getAll(){
        List<ChiTietSanPham> listCTSP = new ArrayList<>();
        try(Session session = HibernateUtil.getFACTORY().openSession()){
            Query<ChiTietSanPham> query = session.createQuery("SELECT ctsp FROM ChiTietSanPham ctsp", ChiTietSanPham.class);
            listCTSP = query.getResultList();
        }catch (Exception e){
            e.printStackTrace();
        }
        return listCTSP;
    }

    public ChiTietSanPham getChiTietSanPhamByMa(Integer idCTSP){
        ChiTietSanPham chiTietSanPham = null;
        try(Session session = HibernateUtil.getFACTORY().openSession()){
            Query query = session.createQuery("FROM ChiTietSanPham where id = : id");
            query.setParameter("id",idCTSP);
            chiTietSanPham = (ChiTietSanPham) query.uniqueResult();
        }catch (Exception e){
            e.printStackTrace();
        }
        return chiTietSanPham;
    }

    public Integer getIdSanPham(Integer id){
        Integer IdSanPham = null;
        try(Session session = HibernateUtil.getFACTORY().openSession()){
            Query query = session.createQuery("FROM SanPham WHERE id = :id");
            query.setParameter("id", IdSanPham);
            IdSanPham = (Integer) query.getSingleResult();
        }
        return IdSanPham;
    }


//    public List<ChiTietSanPham> getPostAndAuthorCategory() {
//        try (Session session = HibernateUtil.getFACTORY().openSession()) {
//            String hql = "FROM ChiTietSanPham P JOIN FETCH P.mauSac  JOIN FETCH P.size JOIN FETCH P.sanPham";
//            Query<ChiTietSanPham> query = session.createQuery(hql, ChiTietSanPham.class);
//            return query.list();
//        } catch (Exception e) {
//            e.printStackTrace();
//            return null;
//        }
//    }

    public Integer getIdMauSac(Integer id){
        Integer IdMauSac = null;
        try(Session session = HibernateUtil.getFACTORY().openSession()){
            Query query = session.createQuery("FROM MauSac WHERE id = :id");
            query.setParameter("id", IdMauSac);
            IdMauSac = (Integer) query.getSingleResult();
        }
        return IdMauSac;
    }

    public Integer getIdKichCo(Integer id){
        Integer IdKichCo = null;
        try(Session session = HibernateUtil.getFACTORY().openSession()){
            Query query = session.createQuery("FROM Size WHERE id = :id");
            query.setParameter("id", IdKichCo);
            IdKichCo = (Integer) query.getSingleResult();
        }
        return IdKichCo;
    }

    public boolean add(ChiTietSanPham chiTietSanPham) {
        Transaction transaction = null;
        try(Session session = HibernateUtil.getFACTORY().openSession()) {
            transaction = session.beginTransaction();
            session.persist(chiTietSanPham);
            transaction.commit();
            return true;
        }catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean delete(ChiTietSanPham chiTietSanPham){
        Transaction transaction = null;
        try(Session session = HibernateUtil.getFACTORY().openSession()){
            transaction = session.beginTransaction();
            session.delete(chiTietSanPham);
            transaction.commit();
            return true;
        }catch (Exception e){
            e.printStackTrace();
        }
        return false;
    }

    // Hàm này dùng để cập nhật
    public boolean update(ChiTietSanPham chiTietSanPham, Integer id) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            transaction = session.beginTransaction();
            Query query = session.createQuery("update ChiTietSanPham set " +
                    "sanPham = :sanPham, " +
                    "mauSac = :mauSac, " +
                    "size = :size, " +
                    "giaBan = :giaBan, " +
                    "soLuongTon = :soLuongTon, " +
                    "trangThai = :trangThai, " +
                    "ngaySua = :ngaySua " +
                    "where id = :id"
            );
            query.setParameter("sanPham", chiTietSanPham.getSanPham());
            query.setParameter("mauSac", chiTietSanPham.getMauSac());
            query.setParameter("size", chiTietSanPham.getSize());
            query.setParameter("giaBan", chiTietSanPham.getGiaBan());
            query.setParameter("soLuongTon", chiTietSanPham.getSoLuongTon());
            query.setParameter("trangThai", chiTietSanPham.getTrangThai());
            query.setParameter("ngaySua", chiTietSanPham.getNgaySua());
            query.setParameter("id", id);
            int result = query.executeUpdate();
            transaction.commit();
            return result > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Hàm này dùng để tìm kiếm chi tiết sản phẩm
    public List<ChiTietSanPham> searchCTSPbyMauSizeSP(String tenMau, String tenSanPham, String tenSize) {
        List<ChiTietSanPham> list = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            Query<ChiTietSanPham> query = session.createQuery("SELECT P FROM ChiTietSanPham P JOIN FETCH P.mauSac  JOIN FETCH P.size JOIN FETCH P.sanPham WHERE P.mauSac.tenMau LIKE: tenMau OR P.sanPham.tenSanPham LIKE: tenSanPham OR P.size.tenSize LIKE : tenSize", ChiTietSanPham.class);
            query.setParameter("tenMau", "%" + tenMau + "%");
            query.setParameter("tenSanPham", "%" + tenSanPham + "%");
            query.setParameter("tenSize", "%" + tenSize + "%");
            list = query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Hàm này dùng để tìm theo khoảng giá sản phẩm
    public List<ChiTietSanPham> search(BigDecimal fromPrice, BigDecimal toPrice) {
        List<ChiTietSanPham> data = new ArrayList<>();
        try (Session session = HibernateUtil.getFACTORY().openSession()) {
            String queryString;
            // Xây dựng câu truy vấn dựa trên giá trị của fromPrice và toPrice
            if (fromPrice.compareTo(BigDecimal.ZERO) == 0 && toPrice.compareTo(BigDecimal.ZERO) > 0) {
                // Truy vấn lấy tất cả các sản phẩm có giá không vượt quá toPrice
                queryString = "SELECT ctsp FROM ChiTietSanPham ctsp WHERE ctsp.giaBan <= :toPrice";
            } else if (fromPrice.compareTo(BigDecimal.ZERO) > 0 && toPrice.compareTo(BigDecimal.ZERO) == 0) {
                // Truy vấn lấy tất cả các sản phẩm có giá không nhỏ hơn fromPrice
                queryString = "SELECT ctsp FROM ChiTietSanPham ctsp WHERE ctsp.giaBan >= :fromPrice";
            } else {
                // Truy vấn lấy các sản phẩm có giá nằm trong khoảng từ fromPrice đến toPrice
                queryString = "SELECT ctsp FROM ChiTietSanPham ctsp WHERE ctsp.giaBan >= :fromPrice AND ctsp.giaBan <= :toPrice";
            }
            // Tạo đối tượng truy vấn
            Query<ChiTietSanPham> query = session.createQuery(queryString, ChiTietSanPham.class);
            // Thiết lập tham số fromPrice nếu fromPrice khác 0
            if (fromPrice.compareTo(BigDecimal.ZERO) > 0) {
                query.setParameter("fromPrice", fromPrice);
            }
            // Thiết lập tham số toPrice nếu toPrice khác 0
            if (toPrice.compareTo(BigDecimal.ZERO) > 0) {
                query.setParameter("toPrice", toPrice);
            }
            // Thực hiện truy vấn và lấy danh sách kết quả
            data = query.list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        // Trả về danh sách kết quả
        return data;
    }

    // Hàm này dùng để đếm số lượng sản phẩm trả về trong db
//    public int getTotalCTSP() {
//        Long soLuongSP = 0L; // Sử dụng Long thay vì Integer vì câu truy vấn trả về một số lớn hơn
//        try (Session session = HibernateUtil.getFACTORY().openSession()) {
//            Query<Long> query = session.createQuery("SELECT COUNT(*) FROM ChiTietSanPham", Long.class);
//            soLuongSP = query.uniqueResult();
//        } catch (Exception e) {
//            e.printStackTrace();
//            // Xử lý lỗi nếu cần
//        }
//        return soLuongSP.intValue(); // Chuyển đổi Long sang int trước khi trả về
//    }
//}

}
