package model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class HoaDonPage {
    private List<HoaDon> hoaDonList;
    // Tổng trang
    private int totalPage;
    // Kích thước trang
    private int pageSize;
    // Trang hiện tại
    private int currentPage;

}
