package model;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "ctsp", schema = "dbo", catalog = "ASM_Java4_Thanhhhph40692")
public class ChiTietSanPham{
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id", nullable = false)
    private int id;
    @ManyToOne
    @JoinColumn(name = "id_sp", nullable = true)
    private SanPham sanPham;
    @ManyToOne
    @JoinColumn(name = "id_mau_sac", nullable = true)
    private MauSac mauSac;
    @ManyToOne
    @JoinColumn(name = "id_size", nullable = true)
    private Size size;
    @Basic
    @Column(name = "gia_ban", nullable = true, precision = 2)
    private BigDecimal giaBan;
    @Basic
    @Column(name = "so_luong_ton", nullable = true)
    private Integer soLuongTon;
    @Basic
    @Column(name = "trang_thai", nullable = true, length = 50)
    private String trangThai;
    @Basic
    @Column(name = "ngay_tao", nullable = true)
    private Timestamp ngayTao;
    @Basic
    @Column(name = "ngay_sua", nullable = true)
    private Timestamp ngaySua;
}
