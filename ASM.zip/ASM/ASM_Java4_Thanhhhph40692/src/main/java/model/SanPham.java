package model;

import jakarta.persistence.*;
import lombok.*;

import java.sql.Timestamp;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "san_pham", schema = "dbo", catalog = "ASM_Java4_Thanhhhph40692")
public class SanPham{
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id", nullable = false)
    private int id;
    @Basic
    @Column(name = "ma_san_pham", nullable = true, length = 255)
    private String maSanPham;
    @Basic
    @Column(name = "ten_san_pham", nullable = true, length = 255)
    private String tenSanPham;
    @Basic
    @Column(name = "trang_thai", nullable = true, length = 50)
    private String trangThai;
    @Basic
    @Column(name = "ngay_tao", nullable = true)
    private Timestamp ngayTao;
    @Basic
    @Column(name = "ngay_sua", nullable = true)
    private Timestamp ngaySua;
    @ManyToOne
    @JoinColumn(name = "id_danh_muc", nullable = true)
    private DanhMuc danhMuc;

}
