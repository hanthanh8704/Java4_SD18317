package model;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.sql.Timestamp;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "hoa_don", schema = "dbo", catalog = "ASM_Java4_Thanhhhph40692")
public class HoaDon {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id", nullable = false)
    private int idHoaDon;
    @ManyToOne
    @JoinColumn(name = "id_khach_hang", nullable = true)
    private KhachHang khachHang;
    @Basic
    @Column(name = "trang_thai", nullable = true, length = 50)
    private String trangThai;
    @Basic
    @Column(name = "ngay_tao", nullable = true)
    private Timestamp ngayTao;
    @Basic
    @Column(name = "ngay_sua", nullable = true)
    private Timestamp ngaySua;
    @Basic
    @Column(name = "dia_chi", nullable = true, length = 255)
    private String diaChi;
    @Basic
    @Column(name = "so_dien_thoai", nullable = true, length = 20)
    private String soDienThoai;
    @Transient
    private BigDecimal tongTien;
}
