package util;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDateTime;

public class TimeUtil {
    public static Timestamp timeNow() {
        Timestamp timeN = new Timestamp(System.currentTimeMillis());
        return timeN;
    }

}
