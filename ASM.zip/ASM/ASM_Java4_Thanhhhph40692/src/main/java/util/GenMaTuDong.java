package util;

public interface GenMaTuDong {
    String maTuDong();
}
