package test;

import model.HoaDon;
import model.HoaDonChiTiet;
import reponse.admin.HoaDonChiTietRepon;
import reponse.admin.HoaDonRepon;
import reponse.user.UserRepon;

import java.util.ArrayList;
import java.util.List;

public class main {
    public static void main2(String[] args) {
        HoaDonRepon hoaDonRepon = new HoaDonRepon();
//        System.out.println(hoaDonRepon.getTongTienByIdHoaDon(1));
//        List<HoaDon> lst = hoaDonRepon.getAll();
        List<Object[]> objectsList = new ArrayList<>();

// Duyệt qua mảng lst
//        for (HoaDon item : lst) {
//            // Lấy thông tin từ mỗi phần tử và thêm vào một đối tượng Object
//            Object[] obj = new Object[]{
//                    item.getIdHoaDon(),
//                    item.getDiaChi(),
//                    item.getNgaySua(),
//                    item.getTrangThai(),
////                    hoaDonRepon.getTongTienByIdHoaDon(item.getId())
//            };

//            // Thêm đối tượng Object vào danh sách
//            objectsList.add(obj);
//        }

    }

//    public static void main(String[] args) {
//        HoaDonChiTietRepon reponHDCT = new HoaDonChiTietRepon();
//        UserRepon repon = new UserRepon();
//        System.out.println(repon.delete(1));
//        for (HoaDonChiTiet hdct : reponHDCT.getHoaDonChiTietByHoaDonId(2)){
//            System.out.println(hdct.getTongTien());
//        };
//    }
}
