package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.SanPham;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "SanPhamServlet", value = {
        "/san-pham/hien-thi",
        "/san-pham/add",
        "/san-pham/delete",
        "/san-pham/search",
})
public class SanPhamServlet extends HttpServlet {
    List<String> listStr = new ArrayList<>();

    public SanPhamServlet() {
        listStr.add("Hang 1");
        listStr.add("Hang 2");
        listStr.add("Hang 3");
        listSP.add(new SanPham("SP001", "quần", 50, 999, "Hang 1", "Con hang"));
        listSP.add(new SanPham("SP002", "áo", 50, 999, "Hang 2", "Het hang"));
        listSP.add(new SanPham("SP003", "tất", 50, 999, "Hang 3", "Con hang"));
        listSP.add(new SanPham("SP004", "áo", 50, 999, "Hang 1", "Het hang"));
        listSP.add(new SanPham("SP005", "tất", 50, 999, "Hang 2", "Con hang"));
    }

    List<SanPham> listSP = new ArrayList<>();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.equals("/san-pham/hien-thi")) {
            this.hienThi(request, response);
        } else if (uri.equals("/san-pham/delete")) {
            this.delete(request, response);
        }
    }

    private void delete(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String ma = request.getParameter("ma");
        for (SanPham sanPham : listSP) {
            if (sanPham.getMa().equals(ma)) {
                listSP.remove(sanPham);
                break;
            }
        }
        if(listSP.size() == 0){
            System.out.println("Danh sách trống");
        }
        response.sendRedirect("/san-pham/hien-thi");
    }

    private void hienThi(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if(listSP.isEmpty()){
            request.setAttribute("error","Danh sach trong");
        }else {
            request.setAttribute("listSP", listSP);
        }
        request.setAttribute("listStr", listStr);
        request.getRequestDispatcher("/views/hien-thi.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if (uri.equals("/san-pham/add")) {
            this.add(request, response);
        } else if (uri.equals("/san-pham/search")) {
            this.search(request, response);
        }
    }

    private void search(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String ten = request.getParameter("ten");
        List<SanPham> listSPSearch = new ArrayList<>();
        for (SanPham gv : listSP) {
            if (gv.getTen().contains(ten)) {
                listSPSearch.add(gv);
            }
        }
        request.setAttribute("listSP", listSPSearch);
        request.setAttribute("listStr", listStr);
        request.getRequestDispatcher("/views/hien-thi.jsp").forward(request, response);
    }

    private void add(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String ma = request.getParameter("ma");
        String ten = request.getParameter("ten");
        Integer soLuong = Integer.valueOf(request.getParameter("soLuong"));
        Integer giaBan = Integer.valueOf(request.getParameter("giaBan"));
        String danhMuc = request.getParameter("danhMuc");
        String trangThai = request.getParameter("trangThai");

        SanPham sanPham = new SanPham(ma,ten,soLuong,giaBan,danhMuc,trangThai);
        listSP.add(sanPham);
        response.sendRedirect("/san-pham/hien-thi");
    }
}














