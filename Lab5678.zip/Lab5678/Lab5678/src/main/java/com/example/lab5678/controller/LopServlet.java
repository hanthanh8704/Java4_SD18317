package com.example.lab5678.controller;

import com.example.lab5678.model.ChuyenNganh;
import com.example.lab5678.model.Lop;
import com.example.lab5678.repository.LopRepository;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "LopServlet", value = {
        "/hien-thi",
        "/add",
        "/detail"
})
public class LopServlet extends HttpServlet {
    LopRepository repon = new LopRepository();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if(uri.equals("/hien-thi")){
            this.hienThi(request,response);
        } else if (uri.equals("/detail")) {
            this.detail(request,response);
        }
    }

    private void detail(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Integer id = Integer.valueOf(request.getParameter("id"));
        List<ChuyenNganh> listCN = repon.getList();
        request.setAttribute("listCN",listCN);
        Lop lop = repon.getSinhVienById(id);
        request.setAttribute("detailLH",lop);
        request.getRequestDispatcher("/view/chi-tiet.jsp").forward(request,response);
    }

    private void hienThi(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Lop> listLopHoc = repon.getAll();
        request.setAttribute("listLopHoc",listLopHoc);
        List<ChuyenNganh> listCN = repon.getList();
        request.setAttribute("listCN",listCN);
        request.getRequestDispatcher("/view/hien-thi.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        if(uri.equals("/add")){
            this.add(request,response);
        }
    }

    private void add(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String ma = request.getParameter("maLop");
        String ten = request.getParameter("tenLop");
        String trangThai = request.getParameter("trangThai");
        Integer idCN = Integer.valueOf(request.getParameter("chuyenNganh"));
        ChuyenNganh chuyenNganh = new ChuyenNganh();
        chuyenNganh.setId(idCN);
        Lop lop = new Lop();
        lop.setMaLop(ma);
        lop.setTenLop(ten);
        lop.setTrangThai(trangThai);
        lop.setChuyenNganh(chuyenNganh);
        repon.add(lop);
        response.sendRedirect("/hien-thi");
    }
}
