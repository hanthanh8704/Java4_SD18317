package com.example.lab5678.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Lop {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id", nullable = false)
    private int id;
    @Basic
    @Column(name = "ma_lop", nullable = true, length = 255)
    private String maLop;
    @Basic
    @Column(name = "ten_lop", nullable = true, length = 255)
    private String tenLop;
    @ManyToOne
    @JoinColumn(name = "id_nganh", nullable = true)
    private ChuyenNganh chuyenNganh;
    @Basic
    @Column(name = "trang_thai", nullable = true, length = 50)
    private String trangThai;

}
