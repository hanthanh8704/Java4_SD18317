package com.example.lab5678.repository;

import com.example.lab5678.model.ChuyenNganh;
import com.example.lab5678.model.Lop;
import com.example.lab5678.util.HibernateUtils;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.ArrayList;
import java.util.List;

public class LopRepository {
    public List<Lop> getAll(){
        List<Lop> list = new ArrayList<>();
        try (Session session = HibernateUtils.getFACTORY().openSession()){
            Query<Lop> query = session.createQuery("FROM Lop", Lop.class);
            list = query.getResultList();
        }catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }

    public List<ChuyenNganh> getList(){
        List<ChuyenNganh> list = new ArrayList<>();
        try (Session session = HibernateUtils.getFACTORY().openSession()){
            Query<ChuyenNganh> query = session.createQuery("FROM ChuyenNganh ", ChuyenNganh.class);
            list = query.getResultList();
        }catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }


    public Lop getSinhVienById(Integer id){
        Lop sinhVien =null;
        try(Session session = HibernateUtils.getFACTORY().openSession()){
            Query<Lop> query = session.createQuery("FROM Lop WHERE id =: id");
            query.setParameter("id",id);
            sinhVien = query.uniqueResult();
        }catch (Exception e){
            e.printStackTrace();
        }
        return sinhVien;
    }

    public boolean add(Lop lop){
        Session session = HibernateUtils.getFACTORY().openSession();
        Transaction transaction = session.beginTransaction();
        try{
            session.save(lop);
            transaction.commit();
            return true;
        }catch (Exception e){
            e.printStackTrace();
            transaction.rollback();
        }
        return false;
    }

    public boolean update(Lop lop){
        Session session = HibernateUtils.getFACTORY().openSession();
        Transaction transaction = session.beginTransaction();
        try{
            session.update(lop);
            transaction.commit();
            return true;
        }catch (Exception e){
            e.printStackTrace();
            transaction.rollback();
        }
        return false;
    }

    public boolean delete(Lop lop){
        Session session = HibernateUtils.getFACTORY().openSession();
        Transaction transaction = session.beginTransaction();
        try{
            session.delete(lop);
            transaction.commit();
            return true;
        }catch (Exception e){
            e.printStackTrace();
            transaction.rollback();
        }
        return false;
    }

//    public List<Lop> searchLopHocByName(String hoTen){
//        List<Lop> list = new ArrayList<>();
//        try (Session session = HibernateUtils.getFACTORY().openSession()) {
//            Query<Lop> query = session.createQuery("FROM SinhVien WHERE hoTen LIKE :hoTen", SinhVien.class);
//            query.setParameter("hoTen", "%" + hoTen + "%");
//            list = query.getResultList();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return list;
//    }
}
